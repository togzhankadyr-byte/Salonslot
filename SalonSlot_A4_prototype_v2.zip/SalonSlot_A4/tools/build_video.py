"""Builds the 2–3 minute demo video (Part C2) from storyboard.json, the recorded clips and,
if they exist, the team's voice recordings video/voice/shot1.* … shot10.* and the real scenes video/real/shot1.*, shot10.*.
Output: video/SalonSlot_demo.mp4 (MP4, H.264 + AAC, 1280x720, 30 fps) and SalonSlot_demo.en.srt.
Usage: python3 tools/build_video.py
"""
import json
import subprocess
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
V = ROOT / "video"
BUILD = V / "build"; BUILD.mkdir(exist_ok=True)
sb = json.load(open(V / "storyboard.json", encoding="utf-8"))
marks = json.load(open(V / "clips" / "marks.json"))
_pf = next((f for f in (ROOT / "partB" / "team_measure.json", ROOT / "partB" / "measure.json") if f.exists()), None)
perf = json.load(open(_pf)) if _pf else None      # the team's DevTools numbers (Part B) win over our own run
W, H, FPS = 1280, 720, 30
MAROON = "#70020F"


def run(cmd):
    subprocess.run(cmd, check=True)


def probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
                         capture_output=True, text=True, check=True).stdout
    return float(out.strip())


# ------------------------------------------------------------------ durations from voice or estimate
def find(folder, stem):
    """First file video/<folder>/<stem>.* (wav, m4a, mp3, mp4, mov …) or None."""
    hits = sorted((V / folder).glob(stem + ".*")) if (V / folder).exists() else []
    return hits[0] if hits else None


(V / "voice_wav").mkdir(exist_ok=True)
for sh in sb["shots"]:
    src = find("voice", f"shot{sh['id']}")
    voice = None
    if src:                                           # any phone format -> clean mono WAV, silence trimmed at both ends
        voice = V / "voice_wav" / f"shot{sh['id']}.wav"
        run(["ffmpeg", "-v", "error", "-y", "-i", str(src), "-ac", "1", "-ar", "48000", "-af",
             "silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,loudnorm=I=-16:TP=-1.5",
             str(voice)])
    words = sum(len(l.split()) for l in sh["lines"])
    sh["voice"] = voice
    speech = probe(voice) if sh["voice"] else words / 2.3
    sh["speech"] = speech
    sh["dur"] = round(max(speech + 1.6, sh.get("min", 0)), 2)   # 0.8 s around the speech; clips play in full
start = 0.0
for sh in sb["shots"]:
    sh["start"] = start; start += sh["dur"]
TOTAL = start
print(f"total {TOTAL:.1f} s")

# ------------------------------------------------------------------ cards (HTML -> PNG)
LOGO = (ROOT / "app/static/img/logo.svg").read_text()
CSS = f"""<style>@import url('file:///usr/share/fonts/opentype/inter/');
*{{box-sizing:border-box}}body{{margin:0;width:{W}px;height:{H}px;font-family:Inter,'DejaVu Sans',sans-serif;color:#1F1A1B;background:#F6F3F3;overflow:hidden}}
.full{{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;padding:40px 80px 130px}}
h1{{font-size:64px;margin:0 0 10px;color:{MAROON}}}h2{{font-size:40px;margin:0 0 18px;color:{MAROON}}}
p{{font-size:28px;margin:6px 0;line-height:1.35}}.muted{{color:#5E5557}}
.logo svg{{width:96px;height:96px;margin-bottom:16px}}
.chip{{display:inline-block;background:#fff;border:2px solid #E4DCDD;border-radius:14px;padding:12px 18px;margin:8px 10px 0 0;font-size:26px}}
.side{{position:absolute;left:520px;top:0;right:0;bottom:0;padding:70px 60px 120px;display:flex;flex-direction:column;justify-content:center}}
.who{{font-size:24px;color:#5E5557;text-transform:uppercase;letter-spacing:1px}}
.tiers{{display:flex;gap:26px;align-items:stretch;margin-top:10px}}.tier{{flex:1;background:#fff;border:3px solid #E4DCDD;border-radius:18px;padding:22px}}
.tier b{{display:block;font-size:30px;color:{MAROON};margin-bottom:8px}}.tier span{{font-size:23px;line-height:1.4;display:block}}
.arrow{{align-self:center;font-size:48px;color:#5E5557}}
table{{border-collapse:collapse;font-size:28px;margin-top:10px}}td,th{{padding:12px 22px;border-bottom:2px solid #E4DCDD;text-align:left}}th{{color:#5E5557;font-size:22px}}
td.big{{font-weight:700;color:#1E6B45}}
</style>"""


def card(name, body):
    path = BUILD / f"card_{name}.png"
    page.set_content(f"<html><head>{CSS}</head><body>{body}</body></html>")
    page.wait_for_timeout(150)
    page.screenshot(path=str(path))
    return path


with sync_playwright() as p:
    b = p.chromium.launch(); page = b.new_page(viewport={"width": W, "height": H})
    cards = {}
    cards["title"] = card("title", f"""<div class="full"><div class="logo">{LOGO}</div>
      <h1>SalonSlot</h1><p style="font-size:34px">Online booking for a hair salon</p>
      <p class="muted">Group SE2622 · Team Salonslot · Aida · Dinara · Togzhan</p>
      <div><span class="chip">Survey, Stage 1: <b>68.8%</b> cannot see free times</span><span class="chip"><b>93.8%</b> want online booking</span></div></div>""")
    for sh in sb["shots"]:
        if sh["visual"].startswith("real:") and not find("real", sh["visual"].split(":")[1]):
            cards[f"real{sh['id']}"] = card(f"real{sh['id']}", f"""<div class="full" style="border:6px dashed #B07A00;background:#FFF8E6">
              <div class="who">Shot {sh['id']} · real scene filmed with a phone – placeholder</div>
              <h2>{sh['heading']}</h2><p>{sh['screen']}</p></div>""")
        if sh["visual"].startswith("clip:") and sh["visual"] != "clip:admin":
            if sh.get("panel"):                       # custom side panel (title, measurement, formats)
                html = sh["panel"].replace("{LOGO}", LOGO)
                if "{PERF}" in html and perf:
                    rows = "".join(f"<tr><td>{k}</td><td>{v['before']}</td><td>{v['after']}</td></tr>" for k, v in perf["table"].items())
                    html = html.replace("{PERF}", f"""<h2>Main screen, Fast 4G</h2><p class="muted" style="font-size:20px">cache disabled · median of 3 loads</p>
                      <table style="font-size:22px"><tr><th></th><th>Before</th><th>After</th></tr>{rows}</table>
                      <p style="margin-top:14px"><b style="color:#1E6B45">−79% data · −53% load time</b></p>""")
                body = f'<div class="side"><div class="who">{sh["speaker"]}</div>{html}</div>'
            else:
                body = f"""<div class="side"><div class="who">{sh['speaker']}</div>
              <h2>{sh['heading']}</h2><p>{sh['onscreen']}</p></div>"""
            cards[f"side{sh['id']}"] = card(f"side{sh['id']}", body)
    cards["architecture"] = card("architecture", """<div class="full"><h2>How SalonSlot works</h2>
      <div class="tiers"><div class="tier"><b>Browser</b><span>phone or laptop</span><span>HTML pages, CSS animation</span><span>SVG logo + icons</span></div>
      <div class="arrow">→</div><div class="tier"><b>Flask · app.py</b><span>checks every request</span><span>free times, roles</span><span>serves static media</span></div>
      <div class="arrow">→</div><div class="tier"><b>SQLite</b><span>9 tables</span><span>bookings, masters, services</span><span>daily backup</span></div></div>
      <p class="muted" style="margin-top:26px">Static media: WebP step images · icons.svg · notify.mp3 · howto.mp4 + captions</p></div>""")
    if perf:
        rows = "".join(f"<tr><td>{k}</td><td>{v['before']}</td><td>{v['after']}</td><td class='big'>{v['change']}</td></tr>"
                       for k, v in perf["table"].items())
        body = f"""<div class="full"><h2>Main screen on Fast 4G (cache disabled)</h2>
          <table><tr><th></th><th>Before</th><th>After</th><th>Change</th></tr>{rows}</table></div>"""
    else:
        body = """<div class="full"><h2>Main screen on Fast 4G</h2><p>Measurement will be added here.</p></div>"""
    cards["performance"] = card("performance", body)
    cards["end"] = card("end", """<div class="full"><h2>Formats we chose</h2>
      <table><tr><th>Content</th><th>Format</th><th>Why</th></tr>
      <tr><td>Images</td><td>WebP, 240 / 480 px</td><td>PNG 174.6 KB → WebP 65.8 KB; page 79% lighter</td></tr>
      <tr><td>Logo and icons</td><td>SVG</td><td>sharp on every screen, a few KB</td></tr>
      <tr><td>Notification sound</td><td>MP3, 64 kbit/s</td><td>plays in every browser, 8 KB</td></tr>
      <tr><td>Video</td><td>MP4 (H.264 + AAC)</td><td>388 KB – smaller than WebM, MOV, MPG; plays everywhere</td></tr></table>
      <p class="muted" style="margin-top:22px;font-size:21px">Screenshots: own work · Icons: Lucide (ISC licence) · Logo, sound, animation, video: own work · No music used</p>
      <p style="margin-top:10px">Thank you!</p></div>""")
    b.close()

# ------------------------------------------------------------------ one video segment per shot
segs = []
for sh in sb["shots"]:
    out = BUILD / f"seg{sh['id']}.mp4"; d = sh["dur"]; kind = sh["visual"]
    enc = ["-r", str(FPS), "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "yuv420p", "-an", "-t", f"{d}"]
    real = find("real", kind.split(":")[1]) if kind.startswith("real:") else None
    if kind.startswith("real:") and real:              # phone video of a real scene, filled to 16:9
        length = probe(real); speed = max(1.0, min(length / d, 1.6)); sh["speed"] = speed
        vf = (f"setpts=PTS/{speed:.3f},tpad=stop_mode=clone:stop_duration={d},"
              f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={FPS},format=yuv420p")
        run(["ffmpeg", "-v", "error", "-y", "-i", str(real), "-vf", vf, "-an", *enc[:-2], "-t", f"{d}", str(out)])
    elif kind == "title" or kind.startswith("graphic:") or kind.startswith("real:"):
        img = cards["title" if kind == "title" else (f"real{sh['id']}" if kind.startswith("real:") else kind.split(":")[1])]
        run(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-i", str(img), "-vf",
             f"fade=in:0:12,fade=out:st={d - 0.4}:d=0.4,format=yuv420p", *enc, str(out)])
    else:
        clip = V / "clips" / f"{kind.split(':')[1]}.webm"
        length = probe(clip)
        speed = max(1.0, min(length / d, 1.6))       # longer clips are played a little faster, shorter ones freeze at the end
        sh["speed"] = speed
        pts = f"setpts=PTS/{speed:.3f},tpad=stop_mode=clone:stop_duration={d}"
        if kind == "clip:admin":
            vf = f"[0:v]{pts},scale={W}:{H},fps={FPS}[v]"
            run(["ffmpeg", "-v", "error", "-y", "-i", str(clip), "-filter_complex", vf, "-map", "[v]", *enc, str(out)])
        else:
            vf = (f"[1:v]{pts},scale=-2:648,pad=iw+12:ih+12:6:6:color=0x1F1A1B,fps={FPS}[ph];"
                  f"[0:v][ph]overlay=x=(520-w)/2+10:y=30[v]")
            run(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-i", str(cards[f"side{sh['id']}"]), "-i", str(clip),
                 "-filter_complex", vf, "-map", "[v]", *enc, str(out)])
    segs.append(out)

lst = BUILD / "segs.txt"
lst.write_text("".join(f"file '{s}'\n" for s in segs))
run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(BUILD / "video_only.mp4")])

# ------------------------------------------------------------------ subtitles (SRT for upload, burned in for the MP4)
def ts(t):
    h, rem = divmod(t, 3600); m, s = divmod(rem, 60)
    return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int(round((s - int(s)) * 1000)):03d}"

srt, n = [], 0
for sh in sb["shots"]:
    t = sh["start"] + 0.8
    total_words = sum(len(l.split()) for l in sh["lines"])
    for line in sh["lines"]:
        dur = sh["speech"] * len(line.split()) / total_words
        n += 1
        srt.append(f"{n}\n{ts(t)} --> {ts(t + dur - 0.05)}\n{sh['speaker']}: {line}\n")
        t += dur
(V / "SalonSlot_demo.en.srt").write_text("\n".join(srt), encoding="utf-8")

# ------------------------------------------------------------------ audio: voices + the chime, or silence
inputs, filters, labels = [], [], []
k = 0
for sh in sb["shots"]:
    if sh["voice"]:
        inputs += ["-i", str(sh["voice"])]
        ms = int((sh["start"] + 0.8) * 1000)
        filters.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=mono,adelay={ms}[a{k}]"); labels.append(f"[a{k}]"); k += 1
admin = next(s for s in sb["shots"] if s["visual"] == "clip:admin")
chime_t = admin["start"] + marks["chime_at"] / admin.get("speed", 1.0)
inputs += ["-i", str(ROOT / "app/static/media/notify.mp3")]
filters.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=mono,volume=0.8,adelay={int(chime_t * 1000)}[a{k}]"); labels.append(f"[a{k}]"); k += 1
inputs += ["-f", "lavfi", "-t", f"{TOTAL}", "-i", "anullsrc=r=48000:cl=mono"]
labels.append(f"[{k}:a]")
filters.append(f"{''.join(labels)}amix=inputs={len(labels)}:normalize=0:duration=longest,atrim=0:{TOTAL}[aout]")
run(["ffmpeg", "-v", "error", "-y", *inputs, "-filter_complex", ";".join(filters), "-map", "[aout]",
     "-c:a", "pcm_s16le", str(BUILD / "audio.wav")])

# ------------------------------------------------------------------ final export
style = ("FontName=Inter,FontSize=12,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H33000000,BackColour=&H33000000,BorderStyle=3,"
         "Outline=6,Shadow=0,MarginV=12,MarginL=40,MarginR=40,Alignment=2")
final = V / "SalonSlot_demo.mp4"
run(["ffmpeg", "-v", "error", "-y", "-i", str(BUILD / "video_only.mp4"), "-i", str(BUILD / "audio.wav"),
     "-vf", f"subtitles={V / 'SalonSlot_demo.en.srt'}:force_style='{style}'",
     "-c:v", "libx264", "-profile:v", "high", "-preset", "slow", "-crf", "22", "-maxrate", "4M", "-bufsize", "8M",
     "-r", str(FPS), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "48000",
     "-movflags", "+faststart", "-shortest", str(final)])
print("saved", final, f"{final.stat().st_size / 1e6:.1f} MB, chime at {chime_t:.1f} s")
