"""Synthesises the SalonSlot notification chime (own work, no samples used).
Two soft bell tones (E6 then A6), 0.7 s, with a quick fade-out, saved as WAV;
then encoded with ffmpeg to MP3 (used in the app) and AAC for the experiment."""
import math, struct, wave, subprocess, sys
RATE = 44100
def tone(freq, start, length, total):
    out = [0.0] * total
    for i in range(int(length * RATE)):
        t = i / RATE
        env = math.exp(-5.5 * t) * min(1, t / 0.005)          # fast attack, bell-like decay
        v = env * (math.sin(2 * math.pi * freq * t) + 0.35 * math.sin(2 * math.pi * 2 * freq * t))
        j = int(start * RATE) + i
        if j < total: out[j] += v
    return out
total = int(0.9 * RATE)
a, b = tone(1318.5, 0.0, 0.6, total), tone(1760.0, 0.16, 0.7, total)
mix = [x + y for x, y in zip(a, b)]
peak = max(abs(v) for v in mix)
with wave.open(sys.argv[1], "w") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE)
    w.writeframes(b"".join(struct.pack("<h", int(v / peak * 0.6 * 32767)) for v in mix))
