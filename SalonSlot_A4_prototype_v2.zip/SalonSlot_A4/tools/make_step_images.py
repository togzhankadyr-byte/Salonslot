"""Raster images of the prototype (Part B2): four screenshots of the booking steps, used in the
"How to book in 4 steps" guide on the salon page.
1. captures each step on a 360 x 640 phone at 3x  -> static/img/originals/stepN.png (1080 x 1920, like a phone screenshot)
2. makes WebP copies 240 px and 480 px wide         -> static/img/photos/stepN-240.webp, -480.webp
3. writes static/img/photos.json (file names, sizes, alt text) used by the templates
Usage: python3 tools/make_step_images.py   (the app must be running on 127.0.0.1:5000)
"""
import io
import json
from pathlib import Path

from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
IMG = ROOT / "app/static/img"
(IMG / "originals").mkdir(parents=True, exist_ok=True); (IMG / "photos").mkdir(exist_ok=True)
U, DAY = "http://127.0.0.1:5000", "2026-10-23"
STEPS = [
    ("step1", "/book", "Step 1 of the booking: the list of services with duration and price"),
    ("step2", "/book?service=1", "Step 2: choose a master or any available master"),
    ("step3", f"/book?service=1&master=2&day={DAY}", "Step 3: days of the week and only the free times, grouped into morning, afternoon and evening"),
    ("step4", f"/book?service=1&master=2&day={DAY}&time=10:00", "Step 4: the form for name, phone and e-mail with the Confirm booking button"),
]
meta, report = {}, []
with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page(viewport={"width": 360, "height": 640}, device_scale_factor=3)
    for key, path, alt in STEPS:
        page.goto(U + path)
        if key == "step4":
            page.fill("input[name=full_name]", "Ailin Test"); page.fill("input[name=phone]", "+7 702 555 11 22")
            page.fill("input[name=email]", "ailin.test@example.com")
        page.screenshot(path=str(IMG / "originals" / f"{key}.png"))
        im = Image.open(IMG / "originals" / f"{key}.png").convert("RGB")
        for w in (240, 480):
            small = im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
            sizes = {}
            for mode, kw in (("lossy q75", dict(quality=75, method=6)), ("lossless", dict(lossless=True, method=6))):
                buf = io.BytesIO(); small.save(buf, "WEBP", **kw); sizes[mode] = buf.getvalue()
            best = min(sizes, key=lambda m: len(sizes[m]))   # keep whichever is smaller for this picture
            (IMG / "photos" / f"{key}-{w}.webp").write_bytes(sizes[best])
            report.append((key, w, {m: round(len(v) / 1024, 1) for m, v in sizes.items()}, best))
        meta[key] = {"orig": f"{key}.png", "file": key, "w": 240, "h": round(1920 * 240 / 1080), "widths": [240, 480], "alt": alt}
    b.close()
(IMG / "photos.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
for r in report:
    print(r)
for key in meta:
    print(key, "original", round((IMG / "originals" / f"{key}.png").stat().st_size / 1024), "KB")
