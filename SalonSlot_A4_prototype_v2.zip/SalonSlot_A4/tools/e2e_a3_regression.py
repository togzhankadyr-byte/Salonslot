"""End-to-end test of the SalonSlot prototype + screenshots for the report."""
import sqlite3
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

U = "http://127.0.0.1:5000"
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
DB = sys.argv[2]
DAY = "2026-10-23"          # tomorrow, Thursday
TIME = "13:00"
ok = []


def check(cond, msg):
    ok.append((bool(cond), msg)); print(("PASS " if cond else "FAIL ") + msg)


with sync_playwright() as p:
    b = p.chromium.launch()
    phone = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2)
    pg = phone.new_page()

    # R1 – salon page with services and prices
    pg.goto(U + "/")
    check("SalonSlot Hair Studio" in pg.content() and "7 000 ₸" in pg.content(), "R1 salon page shows services and prices")
    pg.screenshot(path=OUT / "01_salon_page.png")

    # R2 – step 3 shows only free times
    pg.goto(f"{U}/book?service=1&master=2&day={DAY}")
    slots = pg.locator("a.slot").all_inner_texts()
    con = sqlite3.connect(DB)
    busy = con.execute("SELECT substr(start_time,12,5) FROM appointments WHERE master_id=2 AND status='booked' "
                       "AND date(start_time)=?", (DAY,)).fetchall()
    check(all(t[0] not in slots for t in busy), f"R2 busy times hidden ({len(slots)} free times shown)")
    check(TIME in slots, "13:00 is free before the test booking")
    pg.screenshot(path=OUT / "02_step3_free_times.png")

    # R3 – step 4 contact details, two clients open the same time at once (R4)
    other = phone.new_page()
    url4 = f"{U}/book?service=1&master=2&day={DAY}&time={TIME}"
    pg.goto(url4); other.goto(url4)
    for page, name, tel, mail in [(pg, "Ailin Nurlanova", "+7 702 555 11 22", "ailin.test@gmail.com"),
                                  (other, "Amina Seitova", "+7 701 123 45 67", "amina.test@mail.ru")]:
        page.fill("input[name=full_name]", name); page.fill("input[name=phone]", tel)
        page.fill("input[name=email]", mail); page.check("input[name=consent]")
    pg.screenshot(path=OUT / "03_step4_details.png")
    pg.click("button[type=submit]")
    check("/confirmed/" in pg.url, "R3 first client is booked")
    code = pg.url.rsplit("/", 1)[1]
    pg.screenshot(path=OUT / "04_confirmed.png")
    other.click("button[type=submit]")
    check("just been taken" in other.content(), "R4 second client for the same time is rejected")
    other.screenshot(path=OUT / "05_double_booking_rejected.png")
    row = con.execute("SELECT a.status, c.full_name FROM appointments a JOIN clients c USING(client_id) "
                      "WHERE cancel_code=?", (code,)).fetchone()
    check(row == ("booked", "Ailin Nurlanova"), "R3 row saved in appointments + clients")
    em = con.execute("SELECT to_email, body FROM email_queue WHERE appointment_id=(SELECT appointment_id FROM "
                     "appointments WHERE cancel_code=?)", (code,)).fetchone()
    check(em and code in em[1], "R5 confirmation e-mail with cancel link queued")

    # R2 again – the booked time disappears for everybody
    pg.goto(f"{U}/book?service=1&master=2&day={DAY}")
    check(TIME not in pg.locator("a.slot").all_inner_texts(), "R2 booked time no longer offered")

    # admin: wrong password with SQL injection, then real login (R7, R11)
    desk = b.new_context(viewport={"width": 1280, "height": 800}, device_scale_factor=1.5)
    ad = desk.new_page()
    ad.goto(U + "/login"); ad.fill("input[name=email]", "admin@salon.kz"); ad.fill("input[name=password]", "' OR '1'='1")
    ad.click("button[type=submit]")
    check("Wrong email or password" in ad.content(), "SQL injection login attempt fails")
    ad.screenshot(path=OUT / "06_sql_injection_failed.png")
    ad.fill("input[name=email]", "admin@salon.kz"); ad.fill("input[name=password]", "Admin#Salon26"); ad.click("button[type=submit]")
    ad.goto(f"{U}/admin?day={DAY}&master=2")
    check("Ailin Nurlanova" in ad.content(), "R8 booking appears in the admin schedule")

    # R8 – block out 15:00 for Aliya
    ad.select_option("select[name=master_id]", "2"); ad.select_option("select[name=start]", "17:00")
    ad.click("text=Block out slot")
    check("BLOCKED" in ad.content(), "R8 slot blocked")
    ad.screenshot(path=OUT / "07_admin_schedule_block.png", full_page=True)
    pg.goto(f"{U}/book?service=1&master=2&day={DAY}")
    free = pg.locator("a.slot").all_inner_texts()
    check("17:00" not in free and "16:30" not in free and "16:00" in free, "R8 blocked time hidden from clients")

    # R6 – client cancels with the code, time is free again
    pg.goto(f"{U}/cancel/{code}"); pg.click("text=Cancel booking")
    check("Cancelled" in pg.content(), "R6 booking cancelled with the reference code")
    pg.screenshot(path=OUT / "08_cancelled.png")
    pg.goto(f"{U}/book?service=1&master=2&day={DAY}")
    check(TIME in pg.locator("a.slot").all_inner_texts(), "R6 cancelled time is free again")

    # master sees only own schedule; master cannot block slots (role check)
    ms = b.new_context(viewport={"width": 1280, "height": 800}, device_scale_factor=1.5).new_page()
    ms.goto(U + "/login"); ms.fill("input[name=email]", "aliya.kenzhebekova@salon.kz")
    ms.fill("input[name=password]", "Salon2026!"); ms.click("button[type=submit]")
    ms.goto(f"{U}/admin?day={DAY}&master=1")
    others = con.execute("SELECT COUNT(*) FROM appointments WHERE master_id<>2 AND date(start_time)=?", (DAY,)).fetchone()[0]
    check("Dana Seitova" not in ms.locator("table").inner_text(), f"master sees only own schedule ({others} other bookings hidden)")
    ms.screenshot(path=OUT / "09_master_schedule.png")
    r = ms.request.post(U + "/admin/block", form={"master_id": "2", "day": DAY, "start": "16:00", "minutes": "60"})
    check(r.status == 403, "master cannot block slots (HTTP 403)")
    ms.set_content(r.text()); ms.screenshot(path=OUT / "10_access_denied.png")

    b.close()

print(f"\n{sum(c for c, _ in ok)}/{len(ok)} checks passed")
