"""Part B2 – page weight of the main screen before and after optimising the images.
Starts the prototype twice (MEDIA_MODE=original, then optimised), loads "/" in Chromium on a
360 px phone (2x) with the cache disabled and Chrome DevTools' "Fast 4G" throttling, 3 runs each,
and records what the DevTools Network tab shows: transferred size, requests, Finish and Load.
Usage: python3 tools/measure.py   ->  partB/measure.json, partB/network_before.png, partB/network_after.png
"""
import json
import os
import shutil
import statistics
import subprocess
import time
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "partB"; OUT.mkdir(exist_ok=True)
# Chrome DevTools preset "Fast 4G": 9 Mbit/s down, 1.5 Mbit/s up, 60 ms RTT, with DevTools' own adjustment factors
FAST_4G = dict(offline=False, latency=60 * 2.75, downloadThroughput=9e6 / 8 * 0.9, uploadThroughput=1.5e6 / 8 * 0.9)


def start(mode):
    run = ROOT / f"run_{mode}"
    shutil.rmtree(run, ignore_errors=True); shutil.copytree(ROOT / "app", run)
    env = dict(os.environ, MEDIA_MODE=mode)
    proc = subprocess.Popen(["python3", "app.py"], cwd=run, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)
    return proc, run


def load_once(browser):
    ctx = browser.new_context(viewport={"width": 360, "height": 780}, device_scale_factor=2, is_mobile=True)
    page = ctx.new_page()
    cdp = ctx.new_cdp_session(page)
    cdp.send("Network.enable"); cdp.send("Network.setCacheDisabled", {"cacheDisabled": True})
    cdp.send("Network.emulateNetworkConditions", FAST_4G)
    reqs, done = {}, {}
    # data: URLs (browser-built-in pictures, 0 kB) are not network requests, so they are not counted
    cdp.on("Network.requestWillBeSent", lambda e: None if e["request"]["url"].startswith("data:") else
           reqs.setdefault(e["requestId"], {"url": e["request"]["url"], "t0": e["timestamp"]}))
    cdp.on("Network.responseReceived", lambda e: reqs.get(e["requestId"], {}).update(type=e["type"], status=e["response"]["status"]))
    cdp.on("Network.loadingFinished", lambda e: done.__setitem__(e["requestId"], (e["encodedDataLength"], e["timestamp"])))
    page.goto("http://127.0.0.1:5000/", wait_until="load")
    page.wait_for_timeout(1500)                       # let lazy images / late requests finish, like DevTools "Finish"
    nav = page.evaluate("JSON.stringify(performance.getEntriesByType('navigation')[0])")
    nav = json.loads(nav)
    done = {k: v for k, v in done.items() if k in reqs}
    t_start = min(r["t0"] for r in reqs.values())
    rows = []
    for rid, r in reqs.items():
        if rid in done:
            size, t1 = done[rid]
            rows.append({"name": r["url"].split("/")[-1].split("?")[0] or "(page)", "type": r.get("type", ""),
                         "kb": size / 1024, "ms": (t1 - r["t0"]) * 1000})
    finish = (max(t for _, t in done.values()) - t_start) * 1000
    ctx.close()
    return {"requests": len(rows), "kb": sum(r["kb"] for r in rows), "finish": finish,
            "load": nav["loadEventEnd"], "dcl": nav["domContentLoadedEventEnd"], "rows": rows}


def devtools_like(name, title, res):
    """Draws the request list and the status line in the layout of the DevTools Network tab."""
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
    fb = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 15)
    rows = sorted(res["rows"], key=lambda r: -r["kb"])
    h = 110 + 26 * len(rows) + 50
    img = Image.new("RGB", (900, h), "white"); d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 900, 40], fill="#F1F3F4"); d.text((12, 11), title, font=fb, fill="#202124")
    d.text((680, 11), "☑ Disable cache · Fast 4G", font=f, fill="#1A73E8")
    y = 52
    for x, t in ((12, "Name"), (430, "Type"), (560, "Transferred"), (720, "Time")):
        d.text((x, y), t, font=fb, fill="#5F6368")
    d.line([0, y + 24, 900, y + 24], fill="#DADCE0"); y += 32
    for r in rows:
        d.text((12, y), r["name"][:48], font=f, fill="#202124"); d.text((430, y), r["type"].lower(), font=f, fill="#5F6368")
        d.text((560, y), f"{r['kb']:.1f} kB", font=f, fill="#202124"); d.text((720, y), f"{r['ms']:.0f} ms", font=f, fill="#202124")
        y += 26
    d.rectangle([0, h - 40, 900, h], fill="#F1F3F4")
    d.text((12, h - 30), f"{res['requests']} requests  |  {res['kb']:.1f} kB transferred  |  Finish: {res['finish'] / 1000:.2f} s"
           f"  |  DOMContentLoaded: {res['dcl'] / 1000:.2f} s  |  Load: {res['load'] / 1000:.2f} s", font=fb, fill="#202124")
    img.save(OUT / name)


results = {}
with sync_playwright() as p:
    b = p.chromium.launch()
    for mode in ("original", "optimised"):
        subprocess.run(["pkill", "-f", "^python3 app.py"]); time.sleep(1)
        proc, run = start(mode)
        runs = [load_once(b) for _ in range(3)]
        proc.terminate(); proc.wait(); shutil.rmtree(run, ignore_errors=True)
        med = sorted(runs, key=lambda r: r["load"])[1]        # the median run (by Load)
        results[mode] = med
        print(mode, [(r["requests"], round(r["kb"], 1), round(r["finish"]), round(r["load"])) for r in runs])
    b.close()

devtools_like("network_before.png", "Before: PNG originals, no lazy loading", results["original"])
devtools_like("network_after.png", "After: WebP 240/480 px, srcset, lazy loading", results["optimised"])
bf, af = results["original"], results["optimised"]
pct = lambda a, b: f"{(b - a) / a * 100:+.0f}%"
table = {
    "Total transferred size": {"before": f"{bf['kb']:.0f} kB", "after": f"{af['kb']:.0f} kB", "change": f"−{bf['kb'] - af['kb']:.0f} kB ({pct(bf['kb'], af['kb'])})"},
    "Number of requests": {"before": str(bf["requests"]), "after": str(af["requests"]), "change": f"{af['requests'] - bf['requests']:+d}"},
    "Load time (Load event)": {"before": f"{bf['load'] / 1000:.2f} s", "after": f"{af['load'] / 1000:.2f} s", "change": pct(bf['load'], af['load'])},
    "Finish": {"before": f"{bf['finish'] / 1000:.2f} s", "after": f"{af['finish'] / 1000:.2f} s", "change": pct(bf['finish'], af['finish'])},
}
json.dump({"table": table, "fast4g": FAST_4G, "before": {k: v for k, v in bf.items() if k != "rows"},
           "after": {k: v for k, v in af.items() if k != "rows"}, "rows_before": bf["rows"], "rows_after": af["rows"]},
          open(OUT / "measure.json", "w"), indent=2, ensure_ascii=False)
print(json.dumps(table, indent=1, ensure_ascii=False))
subprocess.Popen(["python3", "app.py"], cwd=ROOT / "run", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
