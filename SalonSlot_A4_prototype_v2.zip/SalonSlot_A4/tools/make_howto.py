"""Makes the 20-second how-to clip shown on the salon page (Part B2, time-based media):
booking clip + the confirmation, scaled to 360x640, H.264 in MP4, no sound track,
WebVTT captions and a WebP poster frame.  Usage: python3 tools/make_howto.py"""
import subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
C, OUT = ROOT / "video/clips", ROOT / "app/static/media"
run = lambda *a: subprocess.run(list(a), check=True)
run("ffmpeg", "-v", "error", "-y", "-i", str(C / "booking.webm"), "-ss", "1.2", "-t", "5.2", "-i", str(C / "confirm.webm"),
    "-filter_complex",
    "[0:v]trim=0:16.2,setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=1,"
    "setpts=PTS/1.08,scale=360:640:flags=lanczos,fps=24,format=yuv420p[v]",
    "-map", "[v]", "-an", "-c:v", "libx264", "-profile:v", "main", "-crf", "28", "-preset", "slow",
    "-movflags", "+faststart", str(OUT / "howto.mp4"))
run("ffmpeg", "-v", "error", "-y", "-ss", "8", "-i", str(OUT / "howto.mp4"), "-frames:v", "1", "-c:v", "libwebp",
    "-quality", "70", str(OUT / "howto-poster.webp"))
cues = [(0.0, 2.0, "Step 1 – choose a service"), (2.0, 4.1, "Step 2 – choose a master"),
        (4.1, 7.6, "Step 3 – choose a day: only free times are shown"), (7.6, 15.0, "Step 4 – enter your name, phone and e-mail"),
        (15.0, 19.8, "Confirm – keep the reference code to cancel")]
f = lambda t: f"00:{int(t // 60):02d}:{t % 60:06.3f}"
(OUT / "howto.en.vtt").write_text("WEBVTT\n\n" + "\n".join(f"{i+1}\n{f(a)} --> {f(b)}\n{t}\n" for i, (a, b, t) in enumerate(cues)), encoding="utf-8")
print("ok")
