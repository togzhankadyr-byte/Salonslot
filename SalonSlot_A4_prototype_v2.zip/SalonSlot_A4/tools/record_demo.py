"""Records the screen clips for the demo video (Part C) and the 20-second how-to clip (Part B)
from the running prototype with Playwright (Chromium). Test data only – no real personal data.
Usage: python3 tools/record_demo.py video/clips run/salon_booking.db
"""
import json
import shutil
import sqlite3
import sys
import threading
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

U = "http://127.0.0.1:5000"
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
DB = sys.argv[2]
import datetime as _dt
_d = _dt.date.today() + _dt.timedelta(days=1)
while _d.weekday() == 6:                      # the salon is closed on Sunday
    _d += _dt.timedelta(days=1)
DAY = _d.isoformat()                          # the next working day, so free times always exist
# Playwright records at CSS-pixel size, so the phone is recorded at 720 x 1280 with page zoom 2:
# the layout is the same as on a 360 x 640 phone, but the video is sharp.
PHONE = dict(viewport={"width": 720, "height": 1280}, record_video_size={"width": 720, "height": 1280})
ZOOM2 = "document.addEventListener('DOMContentLoaded', () => { document.documentElement.style.zoom = '2'; });"
DESK = dict(viewport={"width": 1280, "height": 720}, record_video_size={"width": 1280, "height": 720})
marks = {}


def clip(browser, name, opts, fn):
    ctx = browser.new_context(record_video_dir=str(OUT / "tmp"), **opts)
    if opts is PHONE:
        ctx.add_init_script(ZOOM2)
    page = ctx.new_page()
    t0 = time.time()
    fn(page, t0)
    page.wait_for_timeout(600)
    video = page.video
    ctx.close()
    shutil.move(video.path(), OUT / f"{name}.webm")
    print("recorded", name, round(time.time() - t0, 1), "s")


def scroll(page, total, steps=60, pause=180):
    for _ in range(steps):
        page.mouse.wheel(0, total / steps)
        page.wait_for_timeout(pause)


def salon(page, t0):
    page.goto(U + "/"); page.wait_for_timeout(2500)
    scroll(page, 3000, 50, 150)
    page.wait_for_timeout(800)
    page.goto(U + "/#masters"); page.wait_for_timeout(2500)
    scroll(page, 1800, 40, 150); page.wait_for_timeout(1500)


def booking(page, t0):
    page.goto(U + "/book"); page.wait_for_timeout(2200)
    page.click("text=Women's haircut"); page.wait_for_timeout(2200)
    page.click("text=Aliya Kenzhebekova"); page.wait_for_timeout(1800)
    page.click(f"a.day[href*='{DAY}']"); page.wait_for_timeout(2600)
    page.click("a.slot:text('10:00')"); page.wait_for_timeout(1500)
    page.locator("input[name=full_name]").type("Ailin Test", delay=90)
    page.locator("input[name=phone]").type("+7 702 555 11 22", delay=60)
    page.locator("input[name=email]").type("ailin.test@example.com", delay=45)
    page.check("input[name=consent]"); page.wait_for_timeout(1500)


def confirm(page, t0):
    # continues the same booking: open step 4 again with the details filled, then confirm
    page.goto(f"{U}/book?service=1&master=2&day={DAY}&time=10:00")
    page.fill("input[name=full_name]", "Ailin Test"); page.fill("input[name=phone]", "+7 702 555 11 22")
    page.fill("input[name=email]", "ailin.test@example.com"); page.check("input[name=consent]")
    page.wait_for_timeout(1200)
    page.click("button[type=submit]"); page.wait_for_timeout(4500)
    page.click("text=Cancel this booking"); page.wait_for_timeout(2200)
    page.click("button:text('Cancel booking')"); page.wait_for_timeout(3000)
    page.goto(U + "/#about"); page.wait_for_timeout(3500)


def book_in_background(delay):
    """A second client books from another phone while the administrator watches the schedule."""
    def run():
        time.sleep(delay)
        import urllib.parse, urllib.request
        data = urllib.parse.urlencode({"service": 5, "master": 9, "day": DAY, "time": "16:00",
                                       "full_name": "Amina Test", "phone": "+7 701 123 45 67",
                                       "email": "amina.test@example.com", "consent": "1"}).encode()
        urllib.request.urlopen(U + "/book", data=data)
    threading.Thread(target=run, daemon=True).start()


def admin(page, t0):
    page.goto(U + "/login"); page.wait_for_timeout(800)
    page.locator("input[name=email]").type("admin@salon.kz", delay=50)
    page.locator("input[name=password]").type("Admin#Salon26", delay=50)
    page.click("button[type=submit]"); page.wait_for_timeout(500)
    page.goto(f"{U}/admin?day={DAY}"); page.wait_for_timeout(2000)
    page.click("#sound-toggle"); page.wait_for_timeout(500)
    book_in_background(0.5)
    page.wait_for_selector("#new-booking:not([hidden])", timeout=15000)
    marks["chime_at"] = round(time.time() - t0, 2)          # the chime is added at this moment in the edit
    page.wait_for_timeout(3000)
    page.reload(); page.wait_for_timeout(2500)
    page.select_option("select[name=master_id]", "2"); page.select_option("select[name=start]", "13:00")
    page.wait_for_timeout(800); page.click("text=Block out slot"); page.wait_for_timeout(3000)


def intro(page, t0):
    """Opening shot: the main screen, then a slow scroll to the step images."""
    page.goto(U + "/"); page.wait_for_timeout(4000)
    scroll(page, 900, 30, 160); page.wait_for_timeout(3500)


def outro(page, t0):
    """Ending shot: a second test booking reaches the confirmation page and stays there."""
    page.goto(f"{U}/book?service=5&master=9&day={DAY}&time=12:00")
    page.fill("input[name=full_name]", "Amina Test"); page.fill("input[name=phone]", "+7 700 000 00 01")
    page.fill("input[name=email]", "amina.test@example.com"); page.check("input[name=consent]")
    page.wait_for_timeout(800); page.click("button[type=submit]"); page.wait_for_timeout(9000)


with sync_playwright() as p:
    b = p.chromium.launch()
    clip(b, "salon", PHONE, salon)
    clip(b, "booking", PHONE, booking)
    clip(b, "confirm", PHONE, confirm)
    clip(b, "admin", DESK, admin)
    clip(b, "intro", PHONE, intro)
    clip(b, "outro", PHONE, outro)
    b.close()
shutil.rmtree(OUT / "tmp", ignore_errors=True)
json.dump(marks, open(OUT / "marks.json", "w"))
print(marks)
