"""Part B3 – accessibility checks of the media.
1. axe-core (Deque, MPL-2.0) on the main pages: image-alt, video-caption, color-contrast …
2. contrast ratios (WCAG 2.1 formula) for text placed over images / video and the banner
3. lists every <img>, its alt text, and every <video>/<audio> with autoplay / controls / captions
Usage: python3 tools/a11y_check.py path/to/axe.min.js   (app running on 127.0.0.1:5000) -> partB/a11y.json
"""
import json, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
AXE = Path(sys.argv[1]).read_text()
U = "http://127.0.0.1:5000"

def lum(rgb):
    def ch(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = rgb
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)

def ratio(fg, bg):
    a, b = sorted((lum(fg), lum(bg)), reverse=True)
    return round((a + 0.05) / (b + 0.05), 2)

def over(alpha, top, under):          # colour of a semi-transparent box over a background
    return tuple(round(alpha * t + (1 - alpha) * u) for t, u in zip(top, under))

white, black = (255, 255, 255), (0, 0, 0)
contrast = {
    "Video subtitles: white text on 75% black box, worst case over a white screen": ratio(white, over(0.75, black, white)),
    "How-to clip captions (browser default: white on 80% black), worst case over white": ratio(white, over(0.8, black, white)),
    "New-booking banner: #3D2A00 text on #FFF4D6": ratio((0x3D, 0x2A, 0x00), (0xFF, 0xF4, 0xD6)),
    "Buttons: white text on maroon #70020F": ratio(white, (0x70, 0x02, 0x0F)),
    "Step captions: #1F1A1B text on #F6F3F3 page": ratio((0x1F, 0x1A, 0x1B), (0xF6, 0xF3, 0xF3)),
}
pages = {"/": "Salon page", "/book?service=1&master=2&day=2026-10-23&time=10:00": "Booking step 4", "/login": "Staff login"}
result = {"contrast": contrast, "axe": {}, "images": [], "media": []}
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 360, "height": 780})
    for path, name in pages.items():
        pg.goto(U + path); pg.add_script_tag(content=AXE)
        r = pg.evaluate("axe.run(document, {runOnly: ['wcag2a', 'wcag2aa']})")
        result["axe"][name] = {"violations": [(v["id"], v["impact"], len(v["nodes"])) for v in r["violations"]],
                               "passes": sorted(v["id"] for v in r["passes"])}
    pg.goto(U + "/")
    result["images"] = pg.evaluate("""[...document.querySelectorAll('img')].map(i => ({src: i.getAttribute('src').split('/').pop(),
        alt: i.getAttribute('alt'), loading: i.getAttribute('loading')}))""")
    result["svg_icons_hidden"] = pg.evaluate("[...document.querySelectorAll('svg.ic')].every(s => s.getAttribute('aria-hidden') === 'true')")
    result["media"] = pg.evaluate("""[...document.querySelectorAll('video,audio')].map(m => ({tag: m.tagName, autoplay: m.autoplay,
        controls: m.controls, tracks: [...m.querySelectorAll('track')].map(t => t.kind + ':' + t.srclang)}))""")
    b.close()
for k, v in contrast.items():
    print(f"{v:>6}  {k}")
for k, v in result["axe"].items():
    print(k, "violations:", v["violations"], "| checks passed:", len(v["passes"]))
print("images:", result["images"]); print("icons hidden:", result["svg_icons_hidden"]); print("media:", result["media"])
json.dump(result, open(ROOT / "partB/a11y.json", "w"), indent=2, ensure_ascii=False)
