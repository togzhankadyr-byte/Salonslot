@echo off
chcp 65001 >nul
cd /d "%~dp0"
title SalonSlot - public link
echo ==================================================================
echo   SalonSlot: public link for everyone (works while this window is open)
echo ==================================================================

if not exist "app.py" (
  echo [ERROR] Extract the ZIP first: right click - Extract All, then run this file from the app folder.
  pause & exit /b
)
set PY=
python --version >nul 2>&1 && set PY=python
if not defined PY py --version >nul 2>&1 && set PY=py
if not defined PY (
  echo [ERROR] Python is not installed. Install it from python.org and tick "Add python.exe to PATH".
  start https://www.python.org/downloads/
  pause & exit /b
)
%PY% -c "import flask" >nul 2>&1 || %PY% -m pip install flask

if not exist cloudflared.exe (
  echo Downloading Cloudflare Tunnel - about 55 MB, only the first time...
  curl -L -o cloudflared.exe https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe
)
if not exist cloudflared.exe (
  echo [ERROR] Download failed. Check the internet and run this file again.
  pause & exit /b
)

echo Starting the SalonSlot server in a second window - do not close it.
start "SalonSlot server" cmd /k %PY% app.py
timeout /t 4 >nul
echo.
echo Wait 10-20 seconds. Below, find the line with  https://....trycloudflare.com
echo That is the public link - copy it and send it to anyone. It works on any phone or computer.
echo To stop: close both windows.
echo.
cloudflared.exe tunnel --url http://127.0.0.1:5000
pause
