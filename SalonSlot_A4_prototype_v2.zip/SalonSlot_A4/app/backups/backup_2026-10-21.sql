BEGIN TRANSACTION;
CREATE TABLE appointments (
  appointment_id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id      INTEGER NOT NULL,
  master_id      INTEGER NOT NULL,
  service_id     INTEGER NOT NULL,
  start_time     TEXT NOT NULL,                                   -- 'YYYY-MM-DD HH:MM'
  status         TEXT NOT NULL DEFAULT 'booked'
                 CHECK (status IN ('booked', 'completed', 'cancelled')),
  cancel_code    TEXT NOT NULL UNIQUE,                            -- reference code for the cancel link (R6)
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (client_id)  REFERENCES clients(client_id)   ON DELETE CASCADE,
  FOREIGN KEY (master_id)  REFERENCES masters(master_id)   ON DELETE RESTRICT,
  FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE RESTRICT
);
INSERT INTO "appointments" VALUES(1,6,1,1,'2026-09-01 10:30','completed','MVFBXX7L','2026-08-24 05:30:00');
INSERT INTO "appointments" VALUES(2,24,1,11,'2026-09-01 15:00','completed','Y2PKVEV5','2026-08-24 15:00:00');
INSERT INTO "appointments" VALUES(3,9,8,4,'2026-09-05 17:30','completed','G3GJYEE2','2026-08-26 12:30:00');
INSERT INTO "appointments" VALUES(4,31,7,15,'2026-09-05 09:30','completed','FAE3JB7E','2026-08-27 05:30:00');
INSERT INTO "appointments" VALUES(5,60,9,11,'2026-09-04 12:30','completed','NV2XRFCD','2026-08-27 10:30:00');
INSERT INTO "appointments" VALUES(6,18,1,8,'2026-09-07 13:30','completed','J3DZTRP3','2026-08-28 13:30:00');
INSERT INTO "appointments" VALUES(7,42,2,12,'2026-09-02 16:30','cancelled','FSHHVKCW','2026-08-29 12:30:00');
INSERT INTO "appointments" VALUES(8,3,3,11,'2026-09-02 14:30','completed','MU5LZNFY','2026-08-30 06:30:00');
INSERT INTO "appointments" VALUES(9,24,5,11,'2026-09-09 10:00','completed','MALWHB3H','2026-08-31 08:00:00');
INSERT INTO "appointments" VALUES(10,5,2,11,'2026-09-05 11:30','completed','F66ZVAUR','2026-08-31 09:30:00');
INSERT INTO "appointments" VALUES(11,14,8,4,'2026-09-05 17:00','completed','NDJ44FBG','2026-08-31 10:00:00');
INSERT INTO "appointments" VALUES(12,10,9,5,'2026-09-05 14:30','completed','83QU2CFC','2026-08-31 14:30:00');
INSERT INTO "appointments" VALUES(13,55,4,3,'2026-09-03 13:30','completed','DCQSWU28','2026-09-01 04:30:00');
INSERT INTO "appointments" VALUES(14,31,2,3,'2026-09-08 14:00','completed','85ZY4G3B','2026-09-01 05:00:00');
INSERT INTO "appointments" VALUES(15,15,1,8,'2026-09-07 10:00','completed','NTPWK5N4','2026-09-01 08:00:00');
INSERT INTO "appointments" VALUES(16,51,4,4,'2026-09-11 16:00','completed','VZRMQJHS','2026-09-01 12:00:00');
INSERT INTO "appointments" VALUES(17,9,2,3,'2026-09-11 10:30','completed','NN744B9H','2026-09-02 06:30:00');
INSERT INTO "appointments" VALUES(18,12,2,1,'2026-09-09 09:30','completed','BW6CMT6B','2026-09-02 23:30:00');
INSERT INTO "appointments" VALUES(19,28,9,11,'2026-09-04 14:00','completed','CNEK95VY','2026-09-03 09:00:00');
INSERT INTO "appointments" VALUES(20,17,5,11,'2026-09-12 17:30','completed','W3BYS8WQ','2026-09-03 14:30:00');
INSERT INTO "appointments" VALUES(21,41,1,7,'2026-09-05 16:30','completed','QQ4CQYCA','2026-09-04 08:30:00');
INSERT INTO "appointments" VALUES(22,8,7,3,'2026-09-12 14:00','completed','ZNBMHBSX','2026-09-04 12:00:00');
INSERT INTO "appointments" VALUES(23,58,5,11,'2026-09-11 14:00','completed','NULUSRR9','2026-09-05 05:00:00');
INSERT INTO "appointments" VALUES(24,59,8,2,'2026-09-15 13:30','cancelled','8WVEEVXA','2026-09-06 11:30:00');
INSERT INTO "appointments" VALUES(25,21,10,2,'2026-09-11 11:30','completed','6MTVQJKU','2026-09-07 03:30:00');
INSERT INTO "appointments" VALUES(26,41,4,4,'2026-09-09 12:30','completed','LZ372NUA','2026-09-07 09:30:00');
INSERT INTO "appointments" VALUES(27,33,1,7,'2026-09-08 16:30','completed','T8M9F4QN','2026-09-07 14:30:00');
INSERT INTO "appointments" VALUES(28,44,4,4,'2026-09-16 17:30','completed','87UN6XVP','2026-09-08 13:30:00');
INSERT INTO "appointments" VALUES(29,35,10,6,'2026-09-15 09:30','completed','S85ZYVV6','2026-09-09 03:30:00');
INSERT INTO "appointments" VALUES(30,22,10,3,'2026-09-17 09:30','completed','37A2MTCE','2026-09-09 05:30:00');
INSERT INTO "appointments" VALUES(31,51,2,12,'2026-09-21 16:00','cancelled','3AM9QW46','2026-09-11 08:00:00');
INSERT INTO "appointments" VALUES(32,4,10,3,'2026-09-12 16:00','completed','2E4WJY96','2026-09-11 09:00:00');
INSERT INTO "appointments" VALUES(33,25,3,11,'2026-09-16 14:30','completed','TCNTYTLQ','2026-09-12 04:30:00');
INSERT INTO "appointments" VALUES(34,3,8,2,'2026-09-17 12:30','completed','UN4WUA35','2026-09-12 05:30:00');
INSERT INTO "appointments" VALUES(35,7,9,1,'2026-09-17 16:30','completed','CV9JMN55','2026-09-12 08:30:00');
INSERT INTO "appointments" VALUES(36,40,10,5,'2026-09-15 11:30','completed','BS8C8FN5','2026-09-13 05:30:00');
INSERT INTO "appointments" VALUES(37,56,4,3,'2026-09-16 11:00','completed','E7SPP3KA','2026-09-13 09:00:00');
INSERT INTO "appointments" VALUES(38,25,3,11,'2026-09-15 17:00','completed','UXG6A73H','2026-09-13 11:00:00');
INSERT INTO "appointments" VALUES(39,47,9,6,'2026-09-15 13:00','completed','6AKN4YHK','2026-09-14 12:00:00');
INSERT INTO "appointments" VALUES(40,28,4,4,'2026-09-23 09:00','completed','DUKH3X2X','2026-09-15 06:00:00');
INSERT INTO "appointments" VALUES(41,8,7,4,'2026-09-24 09:30','completed','LEAL7YT9','2026-09-15 07:30:00');
INSERT INTO "appointments" VALUES(42,4,10,5,'2026-09-21 16:30','completed','WLVPBT8S','2026-09-15 13:30:00');
INSERT INTO "appointments" VALUES(43,24,1,5,'2026-09-21 14:30','completed','WBLLGN87','2026-09-15 13:30:00');
INSERT INTO "appointments" VALUES(44,46,7,4,'2026-09-17 13:30','completed','CQWL9QM7','2026-09-16 05:30:00');
INSERT INTO "appointments" VALUES(45,19,8,4,'2026-09-19 17:30','completed','HWGGXLKL','2026-09-16 09:30:00');
INSERT INTO "appointments" VALUES(46,6,2,3,'2026-09-19 15:30','completed','UW28PRC8','2026-09-16 10:30:00');
INSERT INTO "appointments" VALUES(47,32,1,5,'2026-09-26 09:30','completed','LEUMTEYS','2026-09-17 01:30:00');
INSERT INTO "appointments" VALUES(48,15,2,3,'2026-09-18 16:30','completed','8JLMZV2F','2026-09-17 11:30:00');
INSERT INTO "appointments" VALUES(49,28,10,3,'2026-09-22 17:00','cancelled','W9UD4S55','2026-09-17 13:00:00');
INSERT INTO "appointments" VALUES(50,54,5,11,'2026-09-25 09:30','cancelled','6CZ3H6CZ','2026-09-18 08:30:00');
INSERT INTO "appointments" VALUES(51,40,3,7,'2026-09-26 11:30','completed','CA7YH6K6','2026-09-19 02:30:00');
INSERT INTO "appointments" VALUES(52,54,2,11,'2026-09-23 11:30','completed','JZPX982W','2026-09-19 02:30:00');
INSERT INTO "appointments" VALUES(53,8,9,6,'2026-09-28 15:30','completed','PV4MNZ4L','2026-09-19 13:30:00');
INSERT INTO "appointments" VALUES(54,31,7,3,'2026-09-22 16:30','completed','Z42J7E69','2026-09-20 13:30:00');
INSERT INTO "appointments" VALUES(55,2,8,1,'2026-09-28 09:30','completed','GKZTGD8V','2026-09-21 04:30:00');
INSERT INTO "appointments" VALUES(56,51,6,1,'2026-09-29 11:00','completed','4TKYBB8V','2026-09-21 05:00:00');
INSERT INTO "appointments" VALUES(57,41,6,11,'2026-09-24 09:30','completed','YVF5DSEK','2026-09-21 05:30:00');
INSERT INTO "appointments" VALUES(58,16,2,3,'2026-09-26 17:00','completed','LMUHJNMW','2026-09-21 10:00:00');
INSERT INTO "appointments" VALUES(59,18,6,1,'2026-09-28 11:00','completed','ZXWT3VPY','2026-09-23 04:00:00');
INSERT INTO "appointments" VALUES(60,3,4,15,'2026-09-30 12:00','completed','YD6937A8','2026-09-23 07:00:00');
INSERT INTO "appointments" VALUES(61,55,10,3,'2026-10-01 12:00','cancelled','3FQ4C3SJ','2026-09-23 12:00:00');
INSERT INTO "appointments" VALUES(62,39,4,4,'2026-10-03 17:00','completed','ULY4RSFR','2026-09-24 10:00:00');
INSERT INTO "appointments" VALUES(63,31,7,4,'2026-10-01 16:30','completed','FU7MEJGJ','2026-09-24 14:30:00');
INSERT INTO "appointments" VALUES(64,40,6,11,'2026-09-29 15:30','completed','UVWWJLPR','2026-09-25 09:30:00');
INSERT INTO "appointments" VALUES(65,4,9,5,'2026-09-28 10:30','completed','F7AY2GHV','2026-09-25 09:30:00');
INSERT INTO "appointments" VALUES(66,22,3,10,'2026-09-26 14:00','completed','FFWKWZJ7','2026-09-25 13:00:00');
INSERT INTO "appointments" VALUES(67,37,7,4,'2026-10-06 09:30','completed','YWBVW39W','2026-09-26 00:30:00');
INSERT INTO "appointments" VALUES(68,25,3,10,'2026-10-06 15:30','cancelled','JZVJLMR4','2026-09-26 06:30:00');
INSERT INTO "appointments" VALUES(69,28,10,5,'2026-09-29 09:30','completed','2MA3HTP7','2026-09-27 05:30:00');
INSERT INTO "appointments" VALUES(70,47,3,11,'2026-09-29 11:00','completed','5NQ6LAQX','2026-09-28 10:00:00');
INSERT INTO "appointments" VALUES(71,28,1,8,'2026-09-29 16:00','completed','XQM3EVYA','2026-09-28 16:00:00');
INSERT INTO "appointments" VALUES(72,24,2,11,'2026-10-03 14:30','completed','S8AYWWH9','2026-09-29 05:30:00');
INSERT INTO "appointments" VALUES(73,41,9,5,'2026-10-09 09:00','completed','5EJ65WKZ','2026-09-30 01:00:00');
INSERT INTO "appointments" VALUES(74,1,5,13,'2026-10-10 14:30','cancelled','GKDX5RUH','2026-09-30 09:30:00');
INSERT INTO "appointments" VALUES(75,3,1,5,'2026-10-06 17:30','completed','JN9FZTWX','2026-09-30 10:30:00');
INSERT INTO "appointments" VALUES(76,17,5,13,'2026-10-08 10:00','completed','2585JR4J','2026-10-01 00:00:00');
INSERT INTO "appointments" VALUES(77,11,10,3,'2026-10-06 10:00','completed','PEBZPCSZ','2026-10-01 10:00:00');
INSERT INTO "appointments" VALUES(78,18,4,4,'2026-10-09 13:30','completed','EDES6GYZ','2026-10-02 05:30:00');
INSERT INTO "appointments" VALUES(79,20,3,8,'2026-10-03 16:00','cancelled','2AZSW2JF','2026-10-02 12:00:00');
INSERT INTO "appointments" VALUES(80,30,7,4,'2026-10-09 09:30','completed','HUM2843V','2026-10-03 04:30:00');
INSERT INTO "appointments" VALUES(81,48,3,11,'2026-10-14 09:30','completed','BRTLKYPB','2026-10-04 00:30:00');
INSERT INTO "appointments" VALUES(82,40,6,11,'2026-10-10 14:30','completed','3L5T7YKP','2026-10-04 14:30:00');
INSERT INTO "appointments" VALUES(83,50,1,8,'2026-10-13 10:30','completed','XYDWBMYH','2026-10-05 00:30:00');
INSERT INTO "appointments" VALUES(84,53,3,11,'2026-10-13 13:00','cancelled','FZ6J53J6','2026-10-05 08:00:00');
INSERT INTO "appointments" VALUES(85,35,5,1,'2026-10-12 13:00','completed','ZECBZCL8','2026-10-06 10:00:00');
INSERT INTO "appointments" VALUES(86,48,9,11,'2026-10-12 18:00','completed','QM8NEZ8J','2026-10-06 15:00:00');
INSERT INTO "appointments" VALUES(87,45,7,15,'2026-10-10 15:30','completed','M3FYDVDU','2026-10-07 07:30:00');
INSERT INTO "appointments" VALUES(88,43,2,3,'2026-10-14 17:00','completed','Y9CG44X7','2026-10-07 09:00:00');
INSERT INTO "appointments" VALUES(89,41,6,1,'2026-10-14 13:30','cancelled','AZ2K9YNN','2026-10-08 04:30:00');
INSERT INTO "appointments" VALUES(90,35,2,5,'2026-10-10 17:30','cancelled','D9Y7AVVV','2026-10-08 15:30:00');
INSERT INTO "appointments" VALUES(91,52,4,4,'2026-10-16 10:30','completed','S2ZESZWB','2026-10-09 01:30:00');
INSERT INTO "appointments" VALUES(92,37,3,7,'2026-10-19 12:30','completed','PRU5J8JR','2026-10-09 11:30:00');
INSERT INTO "appointments" VALUES(93,14,10,3,'2026-10-16 11:30','completed','ZGBGSH7B','2026-10-10 03:30:00');
INSERT INTO "appointments" VALUES(94,25,2,5,'2026-10-15 13:30','completed','MHRJ8QA6','2026-10-10 09:30:00');
INSERT INTO "appointments" VALUES(95,9,3,7,'2026-10-20 13:00','completed','4ZY7XYS5','2026-10-11 05:00:00');
INSERT INTO "appointments" VALUES(96,58,2,4,'2026-10-19 15:30','completed','JZAM8EQL','2026-10-11 10:30:00');
INSERT INTO "appointments" VALUES(97,57,2,5,'2026-10-22 13:00','cancelled','FVMP2DK7','2026-10-12 04:00:00');
INSERT INTO "appointments" VALUES(98,22,6,1,'2026-10-15 09:00','cancelled','E7X7F67L','2026-10-12 05:00:00');
INSERT INTO "appointments" VALUES(99,57,7,15,'2026-10-13 15:00','completed','LY27PR8N','2026-10-12 08:00:00');
INSERT INTO "appointments" VALUES(100,27,9,1,'2026-10-16 13:00','completed','WW7F55N3','2026-10-13 08:00:00');
INSERT INTO "appointments" VALUES(101,32,2,1,'2026-10-22 15:00','booked','M9XD8T5B','2026-10-13 09:00:00');
INSERT INTO "appointments" VALUES(102,13,1,1,'2026-10-23 11:30','booked','K6RWECTU','2026-10-13 09:30:00');
INSERT INTO "appointments" VALUES(103,46,4,2,'2026-10-17 13:30','completed','MRM4WM5M','2026-10-13 11:30:00');
INSERT INTO "appointments" VALUES(104,39,9,6,'2026-10-19 13:30','cancelled','6YVE4HKF','2026-10-15 03:30:00');
INSERT INTO "appointments" VALUES(105,48,3,8,'2026-10-20 09:00','completed','8EABMBBZ','2026-10-15 08:00:00');
INSERT INTO "appointments" VALUES(106,51,3,11,'2026-10-22 15:30','booked','CQUG6JZ4','2026-10-16 14:30:00');
INSERT INTO "appointments" VALUES(107,38,10,3,'2026-10-26 18:30','booked','XVZY947S','2026-10-16 15:30:00');
INSERT INTO "appointments" VALUES(108,18,3,11,'2026-10-23 12:00','booked','5E97W94A','2026-10-17 07:00:00');
INSERT INTO "appointments" VALUES(109,18,1,8,'2026-10-27 12:30','booked','X43YVCPR','2026-10-17 07:30:00');
INSERT INTO "appointments" VALUES(110,22,7,3,'2026-10-27 15:30','cancelled','ASJ2B239','2026-10-17 09:30:00');
INSERT INTO "appointments" VALUES(111,46,2,4,'2026-10-27 12:30','booked','842WC65A','2026-10-18 04:30:00');
INSERT INTO "appointments" VALUES(112,52,5,11,'2026-10-23 13:30','booked','W6UWV9A6','2026-10-18 11:30:00');
INSERT INTO "appointments" VALUES(113,23,9,11,'2026-10-28 09:30','booked','DRZG5ZXL','2026-10-19 02:30:00');
INSERT INTO "appointments" VALUES(114,37,7,4,'2026-10-22 15:30','booked','A4K9VYLE','2026-10-19 10:30:00');
INSERT INTO "appointments" VALUES(115,19,1,10,'2026-11-04 09:30','booked','H7JFETAQ','2026-10-19 13:00:00');
INSERT INTO "appointments" VALUES(116,60,9,11,'2026-11-11 11:30','booked','RH53FS2L','2026-10-19 15:00:00');
INSERT INTO "appointments" VALUES(117,54,10,6,'2026-10-24 10:30','booked','S7DVA2M4','2026-10-19 15:00:00');
INSERT INTO "appointments" VALUES(118,10,5,1,'2026-10-27 14:30','booked','TCQE9DMT','2026-10-19 18:00:00');
INSERT INTO "appointments" VALUES(119,58,2,11,'2026-11-05 15:30','booked','LH6HNCXW','2026-10-19 18:00:00');
INSERT INTO "appointments" VALUES(120,45,10,5,'2026-11-02 17:00','booked','WWW65HJM','2026-10-19 21:00:00');
INSERT INTO "appointments" VALUES(121,41,1,7,'2026-11-12 12:00','booked','7SVMKFRW','2026-10-19 22:00:00');
INSERT INTO "appointments" VALUES(122,38,10,5,'2026-11-10 16:00','booked','FLFE3GG6','2026-10-19 23:00:00');
INSERT INTO "appointments" VALUES(123,24,3,11,'2026-11-07 15:00','booked','7BZQPNLC','2026-10-19 23:00:00');
INSERT INTO "appointments" VALUES(124,6,2,3,'2026-11-09 09:30','booked','QU6CBG7T','2026-10-20 01:00:00');
INSERT INTO "appointments" VALUES(125,45,6,1,'2026-10-28 11:00','booked','P252TRU9','2026-10-20 02:00:00');
INSERT INTO "appointments" VALUES(126,56,9,1,'2026-10-23 09:30','booked','NP7TVSE7','2026-10-20 02:00:00');
INSERT INTO "appointments" VALUES(127,8,7,3,'2026-11-07 12:30','booked','AFTPJBDN','2026-10-20 04:00:00');
INSERT INTO "appointments" VALUES(128,26,1,5,'2026-10-27 15:30','booked','2SNQ5M8D','2026-10-20 04:00:00');
INSERT INTO "appointments" VALUES(129,42,1,9,'2026-11-03 16:00','booked','VKX5PVXS','2026-10-20 06:00:00');
INSERT INTO "appointments" VALUES(130,11,10,15,'2026-11-13 16:30','booked','KRCVSW6P','2026-10-20 10:00:00');
INSERT INTO "appointments" VALUES(131,45,10,3,'2026-11-03 12:30','cancelled','7AP8FBTC','2026-10-20 13:00:00');
INSERT INTO "appointments" VALUES(132,54,9,11,'2026-11-02 10:00','cancelled','WCCLCUYF','2026-10-20 14:00:00');
INSERT INTO "appointments" VALUES(133,18,1,8,'2026-10-29 15:30','booked','237MV5YK','2026-10-20 15:00:00');
INSERT INTO "appointments" VALUES(134,11,1,7,'2026-11-03 11:30','booked','HNGZWRRF','2026-10-20 15:00:00');
INSERT INTO "appointments" VALUES(135,38,3,8,'2026-10-26 14:00','booked','E4RUC9BL','2026-10-20 15:00:00');
INSERT INTO "appointments" VALUES(136,37,10,3,'2026-10-26 12:00','booked','XKATMQCC','2026-10-20 15:00:00');
INSERT INTO "appointments" VALUES(137,1,9,6,'2026-11-02 13:00','cancelled','NEK72Z9H','2026-10-20 16:00:00');
INSERT INTO "appointments" VALUES(138,7,1,11,'2026-10-28 15:30','booked','V5PYL2TP','2026-10-20 20:00:00');
INSERT INTO "appointments" VALUES(139,14,1,9,'2026-11-14 12:30','booked','YNE3M977','2026-10-20 20:00:00');
INSERT INTO "appointments" VALUES(140,3,2,1,'2026-10-30 15:00','booked','FUASG3RL','2026-10-20 22:00:00');
INSERT INTO "appointments" VALUES(141,42,6,1,'2026-10-24 11:00','booked','7UHED9NZ','2026-10-21 00:00:00');
INSERT INTO "appointments" VALUES(142,52,3,10,'2026-11-07 12:00','booked','EU2C24UQ','2026-10-21 01:00:00');
INSERT INTO "appointments" VALUES(143,15,10,6,'2026-11-12 10:30','booked','F8G7VG7D','2026-10-21 01:00:00');
INSERT INTO "appointments" VALUES(144,14,4,4,'2026-11-13 14:00','booked','EN9CRWAB','2026-10-21 06:00:00');
INSERT INTO "appointments" VALUES(145,58,2,11,'2026-11-02 18:00','booked','T54DK4U5','2026-10-21 07:00:00');
INSERT INTO "appointments" VALUES(146,50,4,4,'2026-10-27 12:30','booked','27XVE8Q5','2026-10-21 07:00:00');
INSERT INTO "appointments" VALUES(147,15,7,3,'2026-10-27 09:00','booked','6LC4ZBVV','2026-10-21 07:00:00');
INSERT INTO "appointments" VALUES(148,23,2,1,'2026-11-06 13:00','booked','6Q96VR96','2026-10-21 07:00:00');
INSERT INTO "appointments" VALUES(149,55,2,3,'2026-11-14 14:30','booked','HSWUQDWT','2026-10-21 10:00:00');
INSERT INTO "appointments" VALUES(150,47,2,3,'2026-11-09 13:00','booked','UAVH6QNY','2026-10-21 10:00:00');
CREATE TABLE blocked_slots (
  block_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  master_id  INTEGER NOT NULL,
  start_time TEXT NOT NULL,
  end_time   TEXT NOT NULL,
  reason     TEXT NOT NULL DEFAULT 'Break',
  created_by INTEGER NOT NULL,
  CHECK (end_time > start_time),
  FOREIGN KEY (master_id)  REFERENCES masters(master_id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(user_id)
);
INSERT INTO "blocked_slots" VALUES(1,5,'2026-10-07 14:00','2026-10-07 15:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(2,3,'2026-10-09 14:00','2026-10-09 15:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(3,7,'2026-10-10 13:00','2026-10-10 14:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(4,7,'2026-10-15 09:00','2026-10-15 19:00','Day off',1);
INSERT INTO "blocked_slots" VALUES(5,1,'2026-10-19 09:00','2026-10-19 19:00','Day off',1);
INSERT INTO "blocked_slots" VALUES(6,3,'2026-10-21 13:00','2026-10-21 14:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(7,3,'2026-10-27 14:00','2026-10-27 15:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(8,6,'2026-11-03 09:00','2026-11-03 19:00','Day off',1);
INSERT INTO "blocked_slots" VALUES(9,4,'2026-11-03 14:00','2026-11-03 15:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(10,7,'2026-11-07 14:00','2026-11-07 15:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(11,5,'2026-11-09 13:00','2026-11-09 14:00','Lunch break',1);
INSERT INTO "blocked_slots" VALUES(12,3,'2026-11-12 13:00','2026-11-12 14:00','Lunch break',1);
CREATE TABLE clients (
  client_id  INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name  TEXT NOT NULL,
  phone      TEXT NOT NULL UNIQUE CHECK (length(phone) >= 10),
  email      TEXT NOT NULL CHECK (email LIKE '%_@_%._%'),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO "clients" VALUES(1,'Gulnara Serikbayova','+7 707 858 33 46','gulnara.serikbayova43@inbox.kz','2026-09-30 09:30:00');
INSERT INTO "clients" VALUES(2,'Laura Bekova','+7 705 876 25 93','laura.bekova17@gmail.com','2026-09-21 04:30:00');
INSERT INTO "clients" VALUES(3,'Timur Saparov','+7 777 185 36 97','timur.saparov65@inbox.kz','2026-08-30 06:30:00');
INSERT INTO "clients" VALUES(4,'Olga Ivanova','+7 707 103 33 18','olga.ivanova89@inbox.kz','2026-09-11 09:00:00');
INSERT INTO "clients" VALUES(5,'Azamat Ospanov','+7 707 905 64 45','azamat.ospanov74@mail.ru','2026-08-31 09:30:00');
INSERT INTO "clients" VALUES(6,'Gulnara Seitova','+7 777 547 54 63','gulnara.seitova45@gmail.com','2026-08-24 05:30:00');
INSERT INTO "clients" VALUES(7,'Kamila Ospanova','+7 747 728 10 62','kamila.ospanova79@gmail.com','2026-09-12 08:30:00');
INSERT INTO "clients" VALUES(8,'Svetlana Saparova','+7 707 430 21 44','svetlana.saparova16@inbox.kz','2026-09-04 12:00:00');
INSERT INTO "clients" VALUES(9,'Aliya Kenzhebekova','+7 771 307 65 37','aliya.kenzhebekova46@inbox.kz','2026-08-26 12:30:00');
INSERT INTO "clients" VALUES(10,'Alexey Iskakov','+7 775 655 46 29','alexey.iskakov63@gmail.com','2026-08-31 14:30:00');
INSERT INTO "clients" VALUES(11,'Daniyar Zhumabekov','+7 777 232 61 99','daniyar.zhumabekov31@inbox.kz','2026-10-01 10:00:00');
INSERT INTO "clients" VALUES(12,'Malika Serikbayova','+7 775 159 47 89','malika.serikbayova34@inbox.kz','2026-09-02 23:30:00');
INSERT INTO "clients" VALUES(13,'Zhanna Ospanova','+7 705 293 42 42','zhanna.ospanova81@gmail.com','2026-10-13 09:30:00');
INSERT INTO "clients" VALUES(14,'Laura Akhmetova','+7 705 609 42 80','laura.akhmetova39@inbox.kz','2026-08-31 10:00:00');
INSERT INTO "clients" VALUES(15,'Malika Kassymova','+7 775 689 10 81','malika.kassymova2@gmail.com','2026-09-01 08:00:00');
INSERT INTO "clients" VALUES(16,'Timur Serikbayov','+7 705 427 14 52','timur.serikbayov1@gmail.com','2026-09-21 10:00:00');
INSERT INTO "clients" VALUES(17,'Aigerim Akhmetova','+7 702 578 47 86','aigerim.akhmetova57@inbox.kz','2026-09-03 14:30:00');
INSERT INTO "clients" VALUES(18,'Yerlan Yesenov','+7 705 569 84 84','yerlan.yesenov23@mail.ru','2026-08-28 13:30:00');
INSERT INTO "clients" VALUES(19,'Dinara Ospanova','+7 707 297 17 99','dinara.ospanova28@mail.ru','2026-09-16 09:30:00');
INSERT INTO "clients" VALUES(20,'Gulnara Kenzhebekova','+7 747 172 22 32','gulnara.kenzhebekova20@inbox.kz','2026-10-02 12:00:00');
INSERT INTO "clients" VALUES(21,'Yerlan Smagulov','+7 775 243 74 66','yerlan.smagulov90@gmail.com','2026-09-07 03:30:00');
INSERT INTO "clients" VALUES(22,'Moldir Smagulova','+7 702 353 96 33','moldir.smagulova63@mail.ru','2026-09-09 05:30:00');
INSERT INTO "clients" VALUES(23,'Sanzhar Ivanov','+7 747 300 13 11','sanzhar.ivanov20@inbox.kz','2026-10-19 02:30:00');
INSERT INTO "clients" VALUES(24,'Marat Baimukhanov','+7 747 666 51 98','marat.baimukhanov99@mail.ru','2026-08-24 15:00:00');
INSERT INTO "clients" VALUES(25,'Zhanna Yesenova','+7 771 689 10 88','zhanna.yesenova20@gmail.com','2026-09-12 04:30:00');
INSERT INTO "clients" VALUES(26,'Timur Petrov','+7 705 859 91 76','timur.petrov95@mail.ru','2026-10-20 04:00:00');
INSERT INTO "clients" VALUES(27,'Aliya Saparova','+7 775 698 59 48','aliya.saparova96@mail.ru','2026-10-13 08:00:00');
INSERT INTO "clients" VALUES(28,'Yelena Serikbayova','+7 777 663 88 99','yelena.serikbayova88@gmail.com','2026-09-03 09:00:00');
INSERT INTO "clients" VALUES(29,'Saule Omarova','+7 701 450 99 56','saule.omarova91@mail.ru','2026-08-30 12:00:00');
INSERT INTO "clients" VALUES(30,'Ruslan Iskakov','+7 707 867 11 68','ruslan.iskakov11@mail.ru','2026-10-03 04:30:00');
INSERT INTO "clients" VALUES(31,'Arman Abenov','+7 702 124 83 92','arman.abenov71@gmail.com','2026-08-27 05:30:00');
INSERT INTO "clients" VALUES(32,'Alexey Nurlanov','+7 701 225 69 16','alexey.nurlanov45@inbox.kz','2026-09-17 01:30:00');
INSERT INTO "clients" VALUES(33,'Azamat Kenzhebekov','+7 707 224 27 29','azamat.kenzhebekov60@mail.ru','2026-09-07 14:30:00');
INSERT INTO "clients" VALUES(34,'Arman Yesenov','+7 702 845 93 94','arman.yesenov19@mail.ru','2026-08-30 12:00:00');
INSERT INTO "clients" VALUES(35,'Indira Smagulova','+7 771 496 62 96','indira.smagulova23@inbox.kz','2026-09-09 03:30:00');
INSERT INTO "clients" VALUES(36,'Laura Kenzhebekova','+7 707 505 76 68','laura.kenzhebekova31@gmail.com','2026-08-30 12:00:00');
INSERT INTO "clients" VALUES(37,'Diana Kenzhebekova','+7 775 748 41 67','diana.kenzhebekova62@mail.ru','2026-09-26 00:30:00');
INSERT INTO "clients" VALUES(38,'Saule Tulegenova','+7 775 418 98 99','saule.tulegenova76@inbox.kz','2026-10-16 15:30:00');
INSERT INTO "clients" VALUES(39,'Malika Zhumabekova','+7 707 432 87 15','malika.zhumabekova22@gmail.com','2026-09-24 10:00:00');
INSERT INTO "clients" VALUES(40,'Alexey Bekov','+7 775 820 39 92','alexey.bekov53@gmail.com','2026-09-13 05:30:00');
INSERT INTO "clients" VALUES(41,'Nazerke Iskakova','+7 747 412 20 95','nazerke.iskakova4@gmail.com','2026-09-04 08:30:00');
INSERT INTO "clients" VALUES(42,'Nazerke Abenova','+7 771 508 22 70','nazerke.abenova43@mail.ru','2026-08-29 12:30:00');
INSERT INTO "clients" VALUES(43,'Balnur Nurlanova','+7 771 473 90 54','balnur.nurlanova14@inbox.kz','2026-10-07 09:00:00');
INSERT INTO "clients" VALUES(44,'Togzhan Akhmetova','+7 775 352 48 49','togzhan.akhmetova12@inbox.kz','2026-09-08 13:30:00');
INSERT INTO "clients" VALUES(45,'Dmitry Kassymov','+7 702 664 18 86','dmitry.kassymov8@mail.ru','2026-10-07 07:30:00');
INSERT INTO "clients" VALUES(46,'Alexey Mukhamedov','+7 775 812 98 91','alexey.mukhamedov90@gmail.com','2026-09-16 05:30:00');
INSERT INTO "clients" VALUES(47,'Asel Petrova','+7 775 944 22 66','asel.petrova45@gmail.com','2026-09-14 12:00:00');
INSERT INTO "clients" VALUES(48,'Togzhan Tulegenova','+7 771 687 84 65','togzhan.tulegenova29@mail.ru','2026-10-04 00:30:00');
INSERT INTO "clients" VALUES(49,'Madina Ivanova','+7 701 282 23 68','madina.ivanova69@gmail.com','2026-08-30 12:00:00');
INSERT INTO "clients" VALUES(50,'Arman Omarov','+7 707 642 52 90','arman.omarov86@mail.ru','2026-10-05 00:30:00');
INSERT INTO "clients" VALUES(51,'Zhanna Seitova','+7 775 417 10 33','zhanna.seitova78@mail.ru','2026-09-01 12:00:00');
INSERT INTO "clients" VALUES(52,'Zarina Baimukhanova','+7 701 740 46 26','zarina.baimukhanova37@inbox.kz','2026-10-09 01:30:00');
INSERT INTO "clients" VALUES(53,'Asel Kenzhebekova','+7 747 463 12 31','asel.kenzhebekova51@mail.ru','2026-10-05 08:00:00');
INSERT INTO "clients" VALUES(54,'Ailin Tulegenova','+7 777 309 35 80','ailin.tulegenova39@mail.ru','2026-09-18 08:30:00');
INSERT INTO "clients" VALUES(55,'Saule Zhumabekova','+7 777 614 56 61','saule.zhumabekova50@inbox.kz','2026-09-01 04:30:00');
INSERT INTO "clients" VALUES(56,'Amina Bekova','+7 747 892 16 63','amina.bekova26@mail.ru','2026-09-13 09:00:00');
INSERT INTO "clients" VALUES(57,'Bekzat Zhumabekov','+7 705 116 20 41','bekzat.zhumabekov29@mail.ru','2026-10-12 04:00:00');
INSERT INTO "clients" VALUES(58,'Timur Ivanov','+7 702 955 99 23','timur.ivanov1@mail.ru','2026-09-05 05:00:00');
INSERT INTO "clients" VALUES(59,'Nursultan Abenov','+7 701 685 87 24','nursultan.abenov26@mail.ru','2026-09-06 11:30:00');
INSERT INTO "clients" VALUES(60,'Malika Saparova','+7 771 307 38 88','malika.saparova40@mail.ru','2026-08-27 10:30:00');
CREATE TABLE email_queue (
  email_id       INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL,
  to_email       TEXT NOT NULL,
  subject        TEXT NOT NULL,
  body           TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed')),
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE
);
INSERT INTO "email_queue" VALUES(1,1,'gulnara.seitova45@gmail.com','SalonSlot: your booking is confirmed','Hello, Gulnara! Your booking: Women''s haircut with Dana Seitova on 01.09.2026 at 10:30. To cancel, open http://127.0.0.1:5000/cancel/MVFBXX7L','sent','2026-08-24 05:30:00');
INSERT INTO "email_queue" VALUES(2,2,'marat.baimukhanov99@mail.ru','SalonSlot: your booking is confirmed','Hello, Marat! Your booking: Blow-dry and styling with Dana Seitova on 01.09.2026 at 15:00. To cancel, open http://127.0.0.1:5000/cancel/Y2PKVEV5','sent','2026-08-24 15:00:00');
INSERT INTO "email_queue" VALUES(3,3,'aliya.kenzhebekova46@inbox.kz','SalonSlot: your booking is confirmed','Hello, Aliya! Your booking: Fringe trim with Kamila Bekova on 05.09.2026 at 17:30. To cancel, open http://127.0.0.1:5000/cancel/G3GJYEE2','sent','2026-08-26 12:30:00');
INSERT INTO "email_queue" VALUES(4,4,'arman.abenov71@gmail.com','SalonSlot: your booking is confirmed','Hello, Arman! Your booking: Beard trim with Timur Tulegenov on 05.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/FAE3JB7E','sent','2026-08-27 05:30:00');
INSERT INTO "email_queue" VALUES(5,5,'malika.saparova40@mail.ru','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Blow-dry and styling with Aruzhan Omarova on 04.09.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/NV2XRFCD','sent','2026-08-27 10:30:00');
INSERT INTO "email_queue" VALUES(6,6,'yerlan.yesenov23@mail.ru','SalonSlot: your booking is confirmed','Hello, Yerlan! Your booking: Root touch-up with Dana Seitova on 07.09.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/J3DZTRP3','sent','2026-08-28 13:30:00');
INSERT INTO "email_queue" VALUES(7,7,'nazerke.abenova43@mail.ru','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Evening hairstyle with Aliya Kenzhebekova on 02.09.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/FSHHVKCW','sent','2026-08-29 12:30:00');
INSERT INTO "email_queue" VALUES(8,8,'timur.saparov65@inbox.kz','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Blow-dry and styling with Madina Abenova on 02.09.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/MU5LZNFY','sent','2026-08-30 06:30:00');
INSERT INTO "email_queue" VALUES(9,9,'marat.baimukhanov99@mail.ru','SalonSlot: your booking is confirmed','Hello, Marat! Your booking: Blow-dry and styling with Zhanna Saparova on 09.09.2026 at 10:00. To cancel, open http://127.0.0.1:5000/cancel/MALWHB3H','sent','2026-08-31 08:00:00');
INSERT INTO "email_queue" VALUES(10,10,'azamat.ospanov74@mail.ru','SalonSlot: your booking is confirmed','Hello, Azamat! Your booking: Blow-dry and styling with Aliya Kenzhebekova on 05.09.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/F66ZVAUR','sent','2026-08-31 09:30:00');
INSERT INTO "email_queue" VALUES(11,11,'laura.akhmetova39@inbox.kz','SalonSlot: your booking is confirmed','Hello, Laura! Your booking: Fringe trim with Kamila Bekova on 05.09.2026 at 17:00. To cancel, open http://127.0.0.1:5000/cancel/NDJ44FBG','sent','2026-08-31 10:00:00');
INSERT INTO "email_queue" VALUES(12,12,'alexey.iskakov63@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Bob cut with Aruzhan Omarova on 05.09.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/83QU2CFC','sent','2026-08-31 14:30:00');
INSERT INTO "email_queue" VALUES(13,13,'saule.zhumabekova50@inbox.kz','SalonSlot: your booking is confirmed','Hello, Saule! Your booking: Children''s haircut with Arman Zhumabekov on 03.09.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/DCQSWU28','sent','2026-09-01 04:30:00');
INSERT INTO "email_queue" VALUES(14,14,'arman.abenov71@gmail.com','SalonSlot: your booking is confirmed','Hello, Arman! Your booking: Children''s haircut with Aliya Kenzhebekova on 08.09.2026 at 14:00. To cancel, open http://127.0.0.1:5000/cancel/85ZY4G3B','sent','2026-09-01 05:00:00');
INSERT INTO "email_queue" VALUES(15,15,'malika.kassymova2@gmail.com','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Root touch-up with Dana Seitova on 07.09.2026 at 10:00. To cancel, open http://127.0.0.1:5000/cancel/NTPWK5N4','sent','2026-09-01 08:00:00');
INSERT INTO "email_queue" VALUES(16,16,'zhanna.seitova78@mail.ru','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Fringe trim with Arman Zhumabekov on 11.09.2026 at 16:00. To cancel, open http://127.0.0.1:5000/cancel/VZRMQJHS','sent','2026-09-01 12:00:00');
INSERT INTO "email_queue" VALUES(17,17,'aliya.kenzhebekova46@inbox.kz','SalonSlot: your booking is confirmed','Hello, Aliya! Your booking: Children''s haircut with Aliya Kenzhebekova on 11.09.2026 at 10:30. To cancel, open http://127.0.0.1:5000/cancel/NN744B9H','sent','2026-09-02 06:30:00');
INSERT INTO "email_queue" VALUES(18,18,'malika.serikbayova34@inbox.kz','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Women''s haircut with Aliya Kenzhebekova on 09.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/BW6CMT6B','sent','2026-09-02 23:30:00');
INSERT INTO "email_queue" VALUES(19,19,'yelena.serikbayova88@gmail.com','SalonSlot: your booking is confirmed','Hello, Yelena! Your booking: Blow-dry and styling with Aruzhan Omarova on 04.09.2026 at 14:00. To cancel, open http://127.0.0.1:5000/cancel/CNEK95VY','sent','2026-09-03 09:00:00');
INSERT INTO "email_queue" VALUES(20,20,'aigerim.akhmetova57@inbox.kz','SalonSlot: your booking is confirmed','Hello, Aigerim! Your booking: Blow-dry and styling with Zhanna Saparova on 12.09.2026 at 17:30. To cancel, open http://127.0.0.1:5000/cancel/W3BYS8WQ','sent','2026-09-03 14:30:00');
INSERT INTO "email_queue" VALUES(21,21,'nazerke.iskakova4@gmail.com','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Hair colouring (one tone) with Dana Seitova on 05.09.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/QQ4CQYCA','sent','2026-09-04 08:30:00');
INSERT INTO "email_queue" VALUES(22,22,'svetlana.saparova16@inbox.kz','SalonSlot: your booking is confirmed','Hello, Svetlana! Your booking: Children''s haircut with Timur Tulegenov on 12.09.2026 at 14:00. To cancel, open http://127.0.0.1:5000/cancel/ZNBMHBSX','sent','2026-09-04 12:00:00');
INSERT INTO "email_queue" VALUES(23,23,'timur.ivanov1@mail.ru','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Blow-dry and styling with Zhanna Saparova on 11.09.2026 at 14:00. To cancel, open http://127.0.0.1:5000/cancel/NULUSRR9','sent','2026-09-05 05:00:00');
INSERT INTO "email_queue" VALUES(24,24,'nursultan.abenov26@mail.ru','SalonSlot: your booking is confirmed','Hello, Nursultan! Your booking: Men''s haircut with Kamila Bekova on 15.09.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/8WVEEVXA','sent','2026-09-06 11:30:00');
INSERT INTO "email_queue" VALUES(25,25,'yerlan.smagulov90@gmail.com','SalonSlot: your booking is confirmed','Hello, Yerlan! Your booking: Men''s haircut with Adilet Nurlanov on 11.09.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/6MTVQJKU','sent','2026-09-07 03:30:00');
INSERT INTO "email_queue" VALUES(26,26,'nazerke.iskakova4@gmail.com','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Fringe trim with Arman Zhumabekov on 09.09.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/LZ372NUA','sent','2026-09-07 09:30:00');
INSERT INTO "email_queue" VALUES(27,27,'azamat.kenzhebekov60@mail.ru','SalonSlot: your booking is confirmed','Hello, Azamat! Your booking: Hair colouring (one tone) with Dana Seitova on 08.09.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/T8M9F4QN','sent','2026-09-07 14:30:00');
INSERT INTO "email_queue" VALUES(28,28,'togzhan.akhmetova12@inbox.kz','SalonSlot: your booking is confirmed','Hello, Togzhan! Your booking: Fringe trim with Arman Zhumabekov on 16.09.2026 at 17:30. To cancel, open http://127.0.0.1:5000/cancel/87UN6XVP','sent','2026-09-08 13:30:00');
INSERT INTO "email_queue" VALUES(29,29,'indira.smagulova23@inbox.kz','SalonSlot: your booking is confirmed','Hello, Indira! Your booking: Wolf cut with Adilet Nurlanov on 15.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/S85ZYVV6','sent','2026-09-09 03:30:00');
INSERT INTO "email_queue" VALUES(30,30,'moldir.smagulova63@mail.ru','SalonSlot: your booking is confirmed','Hello, Moldir! Your booking: Children''s haircut with Adilet Nurlanov on 17.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/37A2MTCE','sent','2026-09-09 05:30:00');
INSERT INTO "email_queue" VALUES(31,31,'zhanna.seitova78@mail.ru','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Evening hairstyle with Aliya Kenzhebekova on 21.09.2026 at 16:00. To cancel, open http://127.0.0.1:5000/cancel/3AM9QW46','sent','2026-09-11 08:00:00');
INSERT INTO "email_queue" VALUES(32,32,'olga.ivanova89@inbox.kz','SalonSlot: your booking is confirmed','Hello, Olga! Your booking: Children''s haircut with Adilet Nurlanov on 12.09.2026 at 16:00. To cancel, open http://127.0.0.1:5000/cancel/2E4WJY96','sent','2026-09-11 09:00:00');
INSERT INTO "email_queue" VALUES(33,33,'zhanna.yesenova20@gmail.com','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Blow-dry and styling with Madina Abenova on 16.09.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/TCNTYTLQ','sent','2026-09-12 04:30:00');
INSERT INTO "email_queue" VALUES(34,34,'timur.saparov65@inbox.kz','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Men''s haircut with Kamila Bekova on 17.09.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/UN4WUA35','sent','2026-09-12 05:30:00');
INSERT INTO "email_queue" VALUES(35,35,'kamila.ospanova79@gmail.com','SalonSlot: your booking is confirmed','Hello, Kamila! Your booking: Women''s haircut with Aruzhan Omarova on 17.09.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/CV9JMN55','sent','2026-09-12 08:30:00');
INSERT INTO "email_queue" VALUES(36,36,'alexey.bekov53@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Bob cut with Adilet Nurlanov on 15.09.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/BS8C8FN5','sent','2026-09-13 05:30:00');
INSERT INTO "email_queue" VALUES(37,37,'amina.bekova26@mail.ru','SalonSlot: your booking is confirmed','Hello, Amina! Your booking: Children''s haircut with Arman Zhumabekov on 16.09.2026 at 11:00. To cancel, open http://127.0.0.1:5000/cancel/E7SPP3KA','sent','2026-09-13 09:00:00');
INSERT INTO "email_queue" VALUES(38,38,'zhanna.yesenova20@gmail.com','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Blow-dry and styling with Madina Abenova on 15.09.2026 at 17:00. To cancel, open http://127.0.0.1:5000/cancel/UXG6A73H','sent','2026-09-13 11:00:00');
INSERT INTO "email_queue" VALUES(39,39,'asel.petrova45@gmail.com','SalonSlot: your booking is confirmed','Hello, Asel! Your booking: Wolf cut with Aruzhan Omarova on 15.09.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/6AKN4YHK','sent','2026-09-14 12:00:00');
INSERT INTO "email_queue" VALUES(40,40,'yelena.serikbayova88@gmail.com','SalonSlot: your booking is confirmed','Hello, Yelena! Your booking: Fringe trim with Arman Zhumabekov on 23.09.2026 at 09:00. To cancel, open http://127.0.0.1:5000/cancel/DUKH3X2X','sent','2026-09-15 06:00:00');
INSERT INTO "email_queue" VALUES(41,41,'svetlana.saparova16@inbox.kz','SalonSlot: your booking is confirmed','Hello, Svetlana! Your booking: Fringe trim with Timur Tulegenov on 24.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/LEAL7YT9','sent','2026-09-15 07:30:00');
INSERT INTO "email_queue" VALUES(42,42,'olga.ivanova89@inbox.kz','SalonSlot: your booking is confirmed','Hello, Olga! Your booking: Bob cut with Adilet Nurlanov on 21.09.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/WLVPBT8S','sent','2026-09-15 13:30:00');
INSERT INTO "email_queue" VALUES(43,43,'marat.baimukhanov99@mail.ru','SalonSlot: your booking is confirmed','Hello, Marat! Your booking: Bob cut with Dana Seitova on 21.09.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/WBLLGN87','sent','2026-09-15 13:30:00');
INSERT INTO "email_queue" VALUES(44,44,'alexey.mukhamedov90@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Fringe trim with Timur Tulegenov on 17.09.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/CQWL9QM7','sent','2026-09-16 05:30:00');
INSERT INTO "email_queue" VALUES(45,45,'dinara.ospanova28@mail.ru','SalonSlot: your booking is confirmed','Hello, Dinara! Your booking: Fringe trim with Kamila Bekova on 19.09.2026 at 17:30. To cancel, open http://127.0.0.1:5000/cancel/HWGGXLKL','sent','2026-09-16 09:30:00');
INSERT INTO "email_queue" VALUES(46,46,'gulnara.seitova45@gmail.com','SalonSlot: your booking is confirmed','Hello, Gulnara! Your booking: Children''s haircut with Aliya Kenzhebekova on 19.09.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/UW28PRC8','sent','2026-09-16 10:30:00');
INSERT INTO "email_queue" VALUES(47,47,'alexey.nurlanov45@inbox.kz','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Bob cut with Dana Seitova on 26.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/LEUMTEYS','sent','2026-09-17 01:30:00');
INSERT INTO "email_queue" VALUES(48,48,'malika.kassymova2@gmail.com','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Children''s haircut with Aliya Kenzhebekova on 18.09.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/8JLMZV2F','sent','2026-09-17 11:30:00');
INSERT INTO "email_queue" VALUES(49,49,'yelena.serikbayova88@gmail.com','SalonSlot: your booking is confirmed','Hello, Yelena! Your booking: Children''s haircut with Adilet Nurlanov on 22.09.2026 at 17:00. To cancel, open http://127.0.0.1:5000/cancel/W9UD4S55','sent','2026-09-17 13:00:00');
INSERT INTO "email_queue" VALUES(50,50,'ailin.tulegenova39@mail.ru','SalonSlot: your booking is confirmed','Hello, Ailin! Your booking: Blow-dry and styling with Zhanna Saparova on 25.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/6CZ3H6CZ','sent','2026-09-18 08:30:00');
INSERT INTO "email_queue" VALUES(51,51,'alexey.bekov53@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Hair colouring (one tone) with Madina Abenova on 26.09.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/CA7YH6K6','sent','2026-09-19 02:30:00');
INSERT INTO "email_queue" VALUES(52,52,'ailin.tulegenova39@mail.ru','SalonSlot: your booking is confirmed','Hello, Ailin! Your booking: Blow-dry and styling with Aliya Kenzhebekova on 23.09.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/JZPX982W','sent','2026-09-19 02:30:00');
INSERT INTO "email_queue" VALUES(53,53,'svetlana.saparova16@inbox.kz','SalonSlot: your booking is confirmed','Hello, Svetlana! Your booking: Wolf cut with Aruzhan Omarova on 28.09.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/PV4MNZ4L','sent','2026-09-19 13:30:00');
INSERT INTO "email_queue" VALUES(54,54,'arman.abenov71@gmail.com','SalonSlot: your booking is confirmed','Hello, Arman! Your booking: Children''s haircut with Timur Tulegenov on 22.09.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/Z42J7E69','sent','2026-09-20 13:30:00');
INSERT INTO "email_queue" VALUES(55,55,'laura.bekova17@gmail.com','SalonSlot: your booking is confirmed','Hello, Laura! Your booking: Women''s haircut with Kamila Bekova on 28.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/GKZTGD8V','sent','2026-09-21 04:30:00');
INSERT INTO "email_queue" VALUES(56,56,'zhanna.seitova78@mail.ru','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Women''s haircut with Saule Akhmetova on 29.09.2026 at 11:00. To cancel, open http://127.0.0.1:5000/cancel/4TKYBB8V','sent','2026-09-21 05:00:00');
INSERT INTO "email_queue" VALUES(57,57,'nazerke.iskakova4@gmail.com','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Blow-dry and styling with Saule Akhmetova on 24.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/YVF5DSEK','sent','2026-09-21 05:30:00');
INSERT INTO "email_queue" VALUES(58,58,'timur.serikbayov1@gmail.com','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Children''s haircut with Aliya Kenzhebekova on 26.09.2026 at 17:00. To cancel, open http://127.0.0.1:5000/cancel/LMUHJNMW','sent','2026-09-21 10:00:00');
INSERT INTO "email_queue" VALUES(59,59,'yerlan.yesenov23@mail.ru','SalonSlot: your booking is confirmed','Hello, Yerlan! Your booking: Women''s haircut with Saule Akhmetova on 28.09.2026 at 11:00. To cancel, open http://127.0.0.1:5000/cancel/ZXWT3VPY','sent','2026-09-23 04:00:00');
INSERT INTO "email_queue" VALUES(60,60,'timur.saparov65@inbox.kz','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Beard trim with Arman Zhumabekov on 30.09.2026 at 12:00. To cancel, open http://127.0.0.1:5000/cancel/YD6937A8','sent','2026-09-23 07:00:00');
INSERT INTO "email_queue" VALUES(61,61,'saule.zhumabekova50@inbox.kz','SalonSlot: your booking is confirmed','Hello, Saule! Your booking: Children''s haircut with Adilet Nurlanov on 01.10.2026 at 12:00. To cancel, open http://127.0.0.1:5000/cancel/3FQ4C3SJ','sent','2026-09-23 12:00:00');
INSERT INTO "email_queue" VALUES(62,62,'malika.zhumabekova22@gmail.com','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Fringe trim with Arman Zhumabekov on 03.10.2026 at 17:00. To cancel, open http://127.0.0.1:5000/cancel/ULY4RSFR','sent','2026-09-24 10:00:00');
INSERT INTO "email_queue" VALUES(63,63,'arman.abenov71@gmail.com','SalonSlot: your booking is confirmed','Hello, Arman! Your booking: Fringe trim with Timur Tulegenov on 01.10.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/FU7MEJGJ','sent','2026-09-24 14:30:00');
INSERT INTO "email_queue" VALUES(64,64,'alexey.bekov53@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Blow-dry and styling with Saule Akhmetova on 29.09.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/UVWWJLPR','sent','2026-09-25 09:30:00');
INSERT INTO "email_queue" VALUES(65,65,'olga.ivanova89@inbox.kz','SalonSlot: your booking is confirmed','Hello, Olga! Your booking: Bob cut with Aruzhan Omarova on 28.09.2026 at 10:30. To cancel, open http://127.0.0.1:5000/cancel/F7AY2GHV','sent','2026-09-25 09:30:00');
INSERT INTO "email_queue" VALUES(66,66,'moldir.smagulova63@mail.ru','SalonSlot: your booking is confirmed','Hello, Moldir! Your booking: Balayage with Madina Abenova on 26.09.2026 at 14:00. To cancel, open http://127.0.0.1:5000/cancel/FFWKWZJ7','sent','2026-09-25 13:00:00');
INSERT INTO "email_queue" VALUES(67,67,'diana.kenzhebekova62@mail.ru','SalonSlot: your booking is confirmed','Hello, Diana! Your booking: Fringe trim with Timur Tulegenov on 06.10.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/YWBVW39W','sent','2026-09-26 00:30:00');
INSERT INTO "email_queue" VALUES(68,68,'zhanna.yesenova20@gmail.com','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Balayage with Madina Abenova on 06.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/JZVJLMR4','sent','2026-09-26 06:30:00');
INSERT INTO "email_queue" VALUES(69,69,'yelena.serikbayova88@gmail.com','SalonSlot: your booking is confirmed','Hello, Yelena! Your booking: Bob cut with Adilet Nurlanov on 29.09.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/2MA3HTP7','sent','2026-09-27 05:30:00');
INSERT INTO "email_queue" VALUES(70,70,'asel.petrova45@gmail.com','SalonSlot: your booking is confirmed','Hello, Asel! Your booking: Blow-dry and styling with Madina Abenova on 29.09.2026 at 11:00. To cancel, open http://127.0.0.1:5000/cancel/5NQ6LAQX','sent','2026-09-28 10:00:00');
INSERT INTO "email_queue" VALUES(71,71,'yelena.serikbayova88@gmail.com','SalonSlot: your booking is confirmed','Hello, Yelena! Your booking: Root touch-up with Dana Seitova on 29.09.2026 at 16:00. To cancel, open http://127.0.0.1:5000/cancel/XQM3EVYA','sent','2026-09-28 16:00:00');
INSERT INTO "email_queue" VALUES(72,72,'marat.baimukhanov99@mail.ru','SalonSlot: your booking is confirmed','Hello, Marat! Your booking: Blow-dry and styling with Aliya Kenzhebekova on 03.10.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/S8AYWWH9','sent','2026-09-29 05:30:00');
INSERT INTO "email_queue" VALUES(73,73,'nazerke.iskakova4@gmail.com','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Bob cut with Aruzhan Omarova on 09.10.2026 at 09:00. To cancel, open http://127.0.0.1:5000/cancel/5EJ65WKZ','sent','2026-09-30 01:00:00');
INSERT INTO "email_queue" VALUES(74,74,'gulnara.serikbayova43@inbox.kz','SalonSlot: your booking is confirmed','Hello, Gulnara! Your booking: Keratin treatment with Zhanna Saparova on 10.10.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/GKDX5RUH','sent','2026-09-30 09:30:00');
INSERT INTO "email_queue" VALUES(75,75,'timur.saparov65@inbox.kz','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Bob cut with Dana Seitova on 06.10.2026 at 17:30. To cancel, open http://127.0.0.1:5000/cancel/JN9FZTWX','sent','2026-09-30 10:30:00');
INSERT INTO "email_queue" VALUES(76,76,'aigerim.akhmetova57@inbox.kz','SalonSlot: your booking is confirmed','Hello, Aigerim! Your booking: Keratin treatment with Zhanna Saparova on 08.10.2026 at 10:00. To cancel, open http://127.0.0.1:5000/cancel/2585JR4J','sent','2026-10-01 00:00:00');
INSERT INTO "email_queue" VALUES(77,77,'daniyar.zhumabekov31@inbox.kz','SalonSlot: your booking is confirmed','Hello, Daniyar! Your booking: Children''s haircut with Adilet Nurlanov on 06.10.2026 at 10:00. To cancel, open http://127.0.0.1:5000/cancel/PEBZPCSZ','sent','2026-10-01 10:00:00');
INSERT INTO "email_queue" VALUES(78,78,'yerlan.yesenov23@mail.ru','SalonSlot: your booking is confirmed','Hello, Yerlan! Your booking: Fringe trim with Arman Zhumabekov on 09.10.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/EDES6GYZ','sent','2026-10-02 05:30:00');
INSERT INTO "email_queue" VALUES(79,79,'gulnara.kenzhebekova20@inbox.kz','SalonSlot: your booking is confirmed','Hello, Gulnara! Your booking: Root touch-up with Madina Abenova on 03.10.2026 at 16:00. To cancel, open http://127.0.0.1:5000/cancel/2AZSW2JF','sent','2026-10-02 12:00:00');
INSERT INTO "email_queue" VALUES(80,80,'ruslan.iskakov11@mail.ru','SalonSlot: your booking is confirmed','Hello, Ruslan! Your booking: Fringe trim with Timur Tulegenov on 09.10.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/HUM2843V','sent','2026-10-03 04:30:00');
INSERT INTO "email_queue" VALUES(81,81,'togzhan.tulegenova29@mail.ru','SalonSlot: your booking is confirmed','Hello, Togzhan! Your booking: Blow-dry and styling with Madina Abenova on 14.10.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/BRTLKYPB','sent','2026-10-04 00:30:00');
INSERT INTO "email_queue" VALUES(82,82,'alexey.bekov53@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Blow-dry and styling with Saule Akhmetova on 10.10.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/3L5T7YKP','sent','2026-10-04 14:30:00');
INSERT INTO "email_queue" VALUES(83,83,'arman.omarov86@mail.ru','SalonSlot: your booking is confirmed','Hello, Arman! Your booking: Root touch-up with Dana Seitova on 13.10.2026 at 10:30. To cancel, open http://127.0.0.1:5000/cancel/XYDWBMYH','sent','2026-10-05 00:30:00');
INSERT INTO "email_queue" VALUES(84,84,'asel.kenzhebekova51@mail.ru','SalonSlot: your booking is confirmed','Hello, Asel! Your booking: Blow-dry and styling with Madina Abenova on 13.10.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/FZ6J53J6','sent','2026-10-05 08:00:00');
INSERT INTO "email_queue" VALUES(85,85,'indira.smagulova23@inbox.kz','SalonSlot: your booking is confirmed','Hello, Indira! Your booking: Women''s haircut with Zhanna Saparova on 12.10.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/ZECBZCL8','sent','2026-10-06 10:00:00');
INSERT INTO "email_queue" VALUES(86,86,'togzhan.tulegenova29@mail.ru','SalonSlot: your booking is confirmed','Hello, Togzhan! Your booking: Blow-dry and styling with Aruzhan Omarova on 12.10.2026 at 18:00. To cancel, open http://127.0.0.1:5000/cancel/QM8NEZ8J','sent','2026-10-06 15:00:00');
INSERT INTO "email_queue" VALUES(87,87,'dmitry.kassymov8@mail.ru','SalonSlot: your booking is confirmed','Hello, Dmitry! Your booking: Beard trim with Timur Tulegenov on 10.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/M3FYDVDU','sent','2026-10-07 07:30:00');
INSERT INTO "email_queue" VALUES(88,88,'balnur.nurlanova14@inbox.kz','SalonSlot: your booking is confirmed','Hello, Balnur! Your booking: Children''s haircut with Aliya Kenzhebekova on 14.10.2026 at 17:00. To cancel, open http://127.0.0.1:5000/cancel/Y9CG44X7','sent','2026-10-07 09:00:00');
INSERT INTO "email_queue" VALUES(89,89,'nazerke.iskakova4@gmail.com','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Women''s haircut with Saule Akhmetova on 14.10.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/AZ2K9YNN','sent','2026-10-08 04:30:00');
INSERT INTO "email_queue" VALUES(90,90,'indira.smagulova23@inbox.kz','SalonSlot: your booking is confirmed','Hello, Indira! Your booking: Bob cut with Aliya Kenzhebekova on 10.10.2026 at 17:30. To cancel, open http://127.0.0.1:5000/cancel/D9Y7AVVV','sent','2026-10-08 15:30:00');
INSERT INTO "email_queue" VALUES(91,91,'zarina.baimukhanova37@inbox.kz','SalonSlot: your booking is confirmed','Hello, Zarina! Your booking: Fringe trim with Arman Zhumabekov on 16.10.2026 at 10:30. To cancel, open http://127.0.0.1:5000/cancel/S2ZESZWB','sent','2026-10-09 01:30:00');
INSERT INTO "email_queue" VALUES(92,92,'diana.kenzhebekova62@mail.ru','SalonSlot: your booking is confirmed','Hello, Diana! Your booking: Hair colouring (one tone) with Madina Abenova on 19.10.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/PRU5J8JR','sent','2026-10-09 11:30:00');
INSERT INTO "email_queue" VALUES(93,93,'laura.akhmetova39@inbox.kz','SalonSlot: your booking is confirmed','Hello, Laura! Your booking: Children''s haircut with Adilet Nurlanov on 16.10.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/ZGBGSH7B','sent','2026-10-10 03:30:00');
INSERT INTO "email_queue" VALUES(94,94,'zhanna.yesenova20@gmail.com','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Bob cut with Aliya Kenzhebekova on 15.10.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/MHRJ8QA6','sent','2026-10-10 09:30:00');
INSERT INTO "email_queue" VALUES(95,95,'aliya.kenzhebekova46@inbox.kz','SalonSlot: your booking is confirmed','Hello, Aliya! Your booking: Hair colouring (one tone) with Madina Abenova on 20.10.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/4ZY7XYS5','sent','2026-10-11 05:00:00');
INSERT INTO "email_queue" VALUES(96,96,'timur.ivanov1@mail.ru','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Fringe trim with Aliya Kenzhebekova on 19.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/JZAM8EQL','sent','2026-10-11 10:30:00');
INSERT INTO "email_queue" VALUES(97,97,'bekzat.zhumabekov29@mail.ru','SalonSlot: your booking is confirmed','Hello, Bekzat! Your booking: Bob cut with Aliya Kenzhebekova on 22.10.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/FVMP2DK7','sent','2026-10-12 04:00:00');
INSERT INTO "email_queue" VALUES(98,98,'moldir.smagulova63@mail.ru','SalonSlot: your booking is confirmed','Hello, Moldir! Your booking: Women''s haircut with Saule Akhmetova on 15.10.2026 at 09:00. To cancel, open http://127.0.0.1:5000/cancel/E7X7F67L','sent','2026-10-12 05:00:00');
INSERT INTO "email_queue" VALUES(99,99,'bekzat.zhumabekov29@mail.ru','SalonSlot: your booking is confirmed','Hello, Bekzat! Your booking: Beard trim with Timur Tulegenov on 13.10.2026 at 15:00. To cancel, open http://127.0.0.1:5000/cancel/LY27PR8N','sent','2026-10-12 08:00:00');
INSERT INTO "email_queue" VALUES(100,100,'aliya.saparova96@mail.ru','SalonSlot: your booking is confirmed','Hello, Aliya! Your booking: Women''s haircut with Aruzhan Omarova on 16.10.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/WW7F55N3','sent','2026-10-13 08:00:00');
INSERT INTO "email_queue" VALUES(101,101,'alexey.nurlanov45@inbox.kz','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Women''s haircut with Aliya Kenzhebekova on 22.10.2026 at 15:00. To cancel, open http://127.0.0.1:5000/cancel/M9XD8T5B','sent','2026-10-13 09:00:00');
INSERT INTO "email_queue" VALUES(102,102,'zhanna.ospanova81@gmail.com','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Women''s haircut with Dana Seitova on 23.10.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/K6RWECTU','sent','2026-10-13 09:30:00');
INSERT INTO "email_queue" VALUES(103,103,'alexey.mukhamedov90@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Men''s haircut with Arman Zhumabekov on 17.10.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/MRM4WM5M','sent','2026-10-13 11:30:00');
INSERT INTO "email_queue" VALUES(104,104,'malika.zhumabekova22@gmail.com','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Wolf cut with Aruzhan Omarova on 19.10.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/6YVE4HKF','sent','2026-10-15 03:30:00');
INSERT INTO "email_queue" VALUES(105,105,'togzhan.tulegenova29@mail.ru','SalonSlot: your booking is confirmed','Hello, Togzhan! Your booking: Root touch-up with Madina Abenova on 20.10.2026 at 09:00. To cancel, open http://127.0.0.1:5000/cancel/8EABMBBZ','sent','2026-10-15 08:00:00');
INSERT INTO "email_queue" VALUES(106,106,'zhanna.seitova78@mail.ru','SalonSlot: your booking is confirmed','Hello, Zhanna! Your booking: Blow-dry and styling with Madina Abenova on 22.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/CQUG6JZ4','sent','2026-10-16 14:30:00');
INSERT INTO "email_queue" VALUES(107,107,'saule.tulegenova76@inbox.kz','SalonSlot: your booking is confirmed','Hello, Saule! Your booking: Children''s haircut with Adilet Nurlanov on 26.10.2026 at 18:30. To cancel, open http://127.0.0.1:5000/cancel/XVZY947S','sent','2026-10-16 15:30:00');
INSERT INTO "email_queue" VALUES(108,108,'yerlan.yesenov23@mail.ru','SalonSlot: your booking is confirmed','Hello, Yerlan! Your booking: Blow-dry and styling with Madina Abenova on 23.10.2026 at 12:00. To cancel, open http://127.0.0.1:5000/cancel/5E97W94A','sent','2026-10-17 07:00:00');
INSERT INTO "email_queue" VALUES(109,109,'yerlan.yesenov23@mail.ru','SalonSlot: your booking is confirmed','Hello, Yerlan! Your booking: Root touch-up with Dana Seitova on 27.10.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/X43YVCPR','sent','2026-10-17 07:30:00');
INSERT INTO "email_queue" VALUES(110,110,'moldir.smagulova63@mail.ru','SalonSlot: your booking is confirmed','Hello, Moldir! Your booking: Children''s haircut with Timur Tulegenov on 27.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/ASJ2B239','sent','2026-10-17 09:30:00');
INSERT INTO "email_queue" VALUES(111,111,'alexey.mukhamedov90@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Fringe trim with Aliya Kenzhebekova on 27.10.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/842WC65A','sent','2026-10-18 04:30:00');
INSERT INTO "email_queue" VALUES(112,112,'zarina.baimukhanova37@inbox.kz','SalonSlot: your booking is confirmed','Hello, Zarina! Your booking: Blow-dry and styling with Zhanna Saparova on 23.10.2026 at 13:30. To cancel, open http://127.0.0.1:5000/cancel/W6UWV9A6','sent','2026-10-18 11:30:00');
INSERT INTO "email_queue" VALUES(113,113,'sanzhar.ivanov20@inbox.kz','SalonSlot: your booking is confirmed','Hello, Sanzhar! Your booking: Blow-dry and styling with Aruzhan Omarova on 28.10.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/DRZG5ZXL','sent','2026-10-19 02:30:00');
INSERT INTO "email_queue" VALUES(114,114,'diana.kenzhebekova62@mail.ru','SalonSlot: your booking is confirmed','Hello, Diana! Your booking: Fringe trim with Timur Tulegenov on 22.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/A4K9VYLE','sent','2026-10-19 10:30:00');
INSERT INTO "email_queue" VALUES(115,115,'dinara.ospanova28@mail.ru','SalonSlot: your booking is confirmed','Hello, Dinara! Your booking: Balayage with Dana Seitova on 04.11.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/H7JFETAQ','sent','2026-10-19 13:00:00');
INSERT INTO "email_queue" VALUES(116,116,'malika.saparova40@mail.ru','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Blow-dry and styling with Aruzhan Omarova on 11.11.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/RH53FS2L','sent','2026-10-19 15:00:00');
INSERT INTO "email_queue" VALUES(117,117,'ailin.tulegenova39@mail.ru','SalonSlot: your booking is confirmed','Hello, Ailin! Your booking: Wolf cut with Adilet Nurlanov on 24.10.2026 at 10:30. To cancel, open http://127.0.0.1:5000/cancel/S7DVA2M4','sent','2026-10-19 15:00:00');
INSERT INTO "email_queue" VALUES(118,118,'alexey.iskakov63@gmail.com','SalonSlot: your booking is confirmed','Hello, Alexey! Your booking: Women''s haircut with Zhanna Saparova on 27.10.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/TCQE9DMT','sent','2026-10-19 18:00:00');
INSERT INTO "email_queue" VALUES(119,119,'timur.ivanov1@mail.ru','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Blow-dry and styling with Aliya Kenzhebekova on 05.11.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/LH6HNCXW','sent','2026-10-19 18:00:00');
INSERT INTO "email_queue" VALUES(120,120,'dmitry.kassymov8@mail.ru','SalonSlot: your booking is confirmed','Hello, Dmitry! Your booking: Bob cut with Adilet Nurlanov on 02.11.2026 at 17:00. To cancel, open http://127.0.0.1:5000/cancel/WWW65HJM','sent','2026-10-19 21:00:00');
INSERT INTO "email_queue" VALUES(121,121,'nazerke.iskakova4@gmail.com','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Hair colouring (one tone) with Dana Seitova on 12.11.2026 at 12:00. To cancel, open http://127.0.0.1:5000/cancel/7SVMKFRW','sent','2026-10-19 22:00:00');
INSERT INTO "email_queue" VALUES(122,122,'saule.tulegenova76@inbox.kz','SalonSlot: your booking is confirmed','Hello, Saule! Your booking: Bob cut with Adilet Nurlanov on 10.11.2026 at 16:00. To cancel, open http://127.0.0.1:5000/cancel/FLFE3GG6','sent','2026-10-19 23:00:00');
INSERT INTO "email_queue" VALUES(123,123,'marat.baimukhanov99@mail.ru','SalonSlot: your booking is confirmed','Hello, Marat! Your booking: Blow-dry and styling with Madina Abenova on 07.11.2026 at 15:00. To cancel, open http://127.0.0.1:5000/cancel/7BZQPNLC','sent','2026-10-19 23:00:00');
INSERT INTO "email_queue" VALUES(124,124,'gulnara.seitova45@gmail.com','SalonSlot: your booking is confirmed','Hello, Gulnara! Your booking: Children''s haircut with Aliya Kenzhebekova on 09.11.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/QU6CBG7T','sent','2026-10-20 01:00:00');
INSERT INTO "email_queue" VALUES(125,125,'dmitry.kassymov8@mail.ru','SalonSlot: your booking is confirmed','Hello, Dmitry! Your booking: Women''s haircut with Saule Akhmetova on 28.10.2026 at 11:00. To cancel, open http://127.0.0.1:5000/cancel/P252TRU9','sent','2026-10-20 02:00:00');
INSERT INTO "email_queue" VALUES(126,126,'amina.bekova26@mail.ru','SalonSlot: your booking is confirmed','Hello, Amina! Your booking: Women''s haircut with Aruzhan Omarova on 23.10.2026 at 09:30. To cancel, open http://127.0.0.1:5000/cancel/NP7TVSE7','sent','2026-10-20 02:00:00');
INSERT INTO "email_queue" VALUES(127,127,'svetlana.saparova16@inbox.kz','SalonSlot: your booking is confirmed','Hello, Svetlana! Your booking: Children''s haircut with Timur Tulegenov on 07.11.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/AFTPJBDN','sent','2026-10-20 04:00:00');
INSERT INTO "email_queue" VALUES(128,128,'timur.petrov95@mail.ru','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Bob cut with Dana Seitova on 27.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/2SNQ5M8D','sent','2026-10-20 04:00:00');
INSERT INTO "email_queue" VALUES(129,129,'nazerke.abenova43@mail.ru','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Highlights with Dana Seitova on 03.11.2026 at 16:00. To cancel, open http://127.0.0.1:5000/cancel/VKX5PVXS','sent','2026-10-20 06:00:00');
INSERT INTO "email_queue" VALUES(130,130,'daniyar.zhumabekov31@inbox.kz','SalonSlot: your booking is confirmed','Hello, Daniyar! Your booking: Beard trim with Adilet Nurlanov on 13.11.2026 at 16:30. To cancel, open http://127.0.0.1:5000/cancel/KRCVSW6P','sent','2026-10-20 10:00:00');
INSERT INTO "email_queue" VALUES(131,131,'dmitry.kassymov8@mail.ru','SalonSlot: your booking is confirmed','Hello, Dmitry! Your booking: Children''s haircut with Adilet Nurlanov on 03.11.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/7AP8FBTC','sent','2026-10-20 13:00:00');
INSERT INTO "email_queue" VALUES(132,132,'ailin.tulegenova39@mail.ru','SalonSlot: your booking is confirmed','Hello, Ailin! Your booking: Blow-dry and styling with Aruzhan Omarova on 02.11.2026 at 10:00. To cancel, open http://127.0.0.1:5000/cancel/WCCLCUYF','sent','2026-10-20 14:00:00');
INSERT INTO "email_queue" VALUES(133,133,'yerlan.yesenov23@mail.ru','SalonSlot: your booking is confirmed','Hello, Yerlan! Your booking: Root touch-up with Dana Seitova on 29.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/237MV5YK','sent','2026-10-20 15:00:00');
INSERT INTO "email_queue" VALUES(134,134,'daniyar.zhumabekov31@inbox.kz','SalonSlot: your booking is confirmed','Hello, Daniyar! Your booking: Hair colouring (one tone) with Dana Seitova on 03.11.2026 at 11:30. To cancel, open http://127.0.0.1:5000/cancel/HNGZWRRF','sent','2026-10-20 15:00:00');
INSERT INTO "email_queue" VALUES(135,135,'saule.tulegenova76@inbox.kz','SalonSlot: your booking is confirmed','Hello, Saule! Your booking: Root touch-up with Madina Abenova on 26.10.2026 at 14:00. To cancel, open http://127.0.0.1:5000/cancel/E4RUC9BL','sent','2026-10-20 15:00:00');
INSERT INTO "email_queue" VALUES(136,136,'diana.kenzhebekova62@mail.ru','SalonSlot: your booking is confirmed','Hello, Diana! Your booking: Children''s haircut with Adilet Nurlanov on 26.10.2026 at 12:00. To cancel, open http://127.0.0.1:5000/cancel/XKATMQCC','sent','2026-10-20 15:00:00');
INSERT INTO "email_queue" VALUES(137,137,'gulnara.serikbayova43@inbox.kz','SalonSlot: your booking is confirmed','Hello, Gulnara! Your booking: Wolf cut with Aruzhan Omarova on 02.11.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/NEK72Z9H','sent','2026-10-20 16:00:00');
INSERT INTO "email_queue" VALUES(138,138,'kamila.ospanova79@gmail.com','SalonSlot: your booking is confirmed','Hello, Kamila! Your booking: Blow-dry and styling with Dana Seitova on 28.10.2026 at 15:30. To cancel, open http://127.0.0.1:5000/cancel/V5PYL2TP','sent','2026-10-20 20:00:00');
INSERT INTO "email_queue" VALUES(139,139,'laura.akhmetova39@inbox.kz','SalonSlot: your booking is confirmed','Hello, Laura! Your booking: Highlights with Dana Seitova on 14.11.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/YNE3M977','sent','2026-10-20 20:00:00');
INSERT INTO "email_queue" VALUES(140,140,'timur.saparov65@inbox.kz','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Women''s haircut with Aliya Kenzhebekova on 30.10.2026 at 15:00. To cancel, open http://127.0.0.1:5000/cancel/FUASG3RL','sent','2026-10-20 22:00:00');
INSERT INTO "email_queue" VALUES(141,141,'nazerke.abenova43@mail.ru','SalonSlot: your booking is confirmed','Hello, Nazerke! Your booking: Women''s haircut with Saule Akhmetova on 24.10.2026 at 11:00. To cancel, open http://127.0.0.1:5000/cancel/7UHED9NZ','sent','2026-10-21 00:00:00');
INSERT INTO "email_queue" VALUES(142,142,'zarina.baimukhanova37@inbox.kz','SalonSlot: your booking is confirmed','Hello, Zarina! Your booking: Balayage with Madina Abenova on 07.11.2026 at 12:00. To cancel, open http://127.0.0.1:5000/cancel/EU2C24UQ','sent','2026-10-21 01:00:00');
INSERT INTO "email_queue" VALUES(143,143,'malika.kassymova2@gmail.com','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Wolf cut with Adilet Nurlanov on 12.11.2026 at 10:30. To cancel, open http://127.0.0.1:5000/cancel/F8G7VG7D','sent','2026-10-21 01:00:00');
INSERT INTO "email_queue" VALUES(144,144,'laura.akhmetova39@inbox.kz','SalonSlot: your booking is confirmed','Hello, Laura! Your booking: Fringe trim with Arman Zhumabekov on 13.11.2026 at 14:00. To cancel, open http://127.0.0.1:5000/cancel/EN9CRWAB','sent','2026-10-21 06:00:00');
INSERT INTO "email_queue" VALUES(145,145,'timur.ivanov1@mail.ru','SalonSlot: your booking is confirmed','Hello, Timur! Your booking: Blow-dry and styling with Aliya Kenzhebekova on 02.11.2026 at 18:00. To cancel, open http://127.0.0.1:5000/cancel/T54DK4U5','sent','2026-10-21 07:00:00');
INSERT INTO "email_queue" VALUES(146,146,'arman.omarov86@mail.ru','SalonSlot: your booking is confirmed','Hello, Arman! Your booking: Fringe trim with Arman Zhumabekov on 27.10.2026 at 12:30. To cancel, open http://127.0.0.1:5000/cancel/27XVE8Q5','sent','2026-10-21 07:00:00');
INSERT INTO "email_queue" VALUES(147,147,'malika.kassymova2@gmail.com','SalonSlot: your booking is confirmed','Hello, Malika! Your booking: Children''s haircut with Timur Tulegenov on 27.10.2026 at 09:00. To cancel, open http://127.0.0.1:5000/cancel/6LC4ZBVV','sent','2026-10-21 07:00:00');
INSERT INTO "email_queue" VALUES(148,148,'sanzhar.ivanov20@inbox.kz','SalonSlot: your booking is confirmed','Hello, Sanzhar! Your booking: Women''s haircut with Aliya Kenzhebekova on 06.11.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/6Q96VR96','sent','2026-10-21 07:00:00');
INSERT INTO "email_queue" VALUES(149,149,'saule.zhumabekova50@inbox.kz','SalonSlot: your booking is confirmed','Hello, Saule! Your booking: Children''s haircut with Aliya Kenzhebekova on 14.11.2026 at 14:30. To cancel, open http://127.0.0.1:5000/cancel/HSWUQDWT','sent','2026-10-21 10:00:00');
INSERT INTO "email_queue" VALUES(150,150,'asel.petrova45@gmail.com','SalonSlot: your booking is confirmed','Hello, Asel! Your booking: Children''s haircut with Aliya Kenzhebekova on 09.11.2026 at 13:00. To cancel, open http://127.0.0.1:5000/cancel/UAVH6QNY','sent','2026-10-21 10:00:00');
CREATE TABLE master_services (
  master_id  INTEGER NOT NULL,
  service_id INTEGER NOT NULL,
  PRIMARY KEY (master_id, service_id),
  FOREIGN KEY (master_id)  REFERENCES masters(master_id)   ON DELETE CASCADE,
  FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE
);
INSERT INTO "master_services" VALUES(1,1);
INSERT INTO "master_services" VALUES(1,5);
INSERT INTO "master_services" VALUES(1,7);
INSERT INTO "master_services" VALUES(1,8);
INSERT INTO "master_services" VALUES(1,9);
INSERT INTO "master_services" VALUES(1,10);
INSERT INTO "master_services" VALUES(1,11);
INSERT INTO "master_services" VALUES(2,1);
INSERT INTO "master_services" VALUES(2,3);
INSERT INTO "master_services" VALUES(2,4);
INSERT INTO "master_services" VALUES(2,5);
INSERT INTO "master_services" VALUES(2,11);
INSERT INTO "master_services" VALUES(2,12);
INSERT INTO "master_services" VALUES(3,7);
INSERT INTO "master_services" VALUES(3,8);
INSERT INTO "master_services" VALUES(3,9);
INSERT INTO "master_services" VALUES(3,10);
INSERT INTO "master_services" VALUES(3,11);
INSERT INTO "master_services" VALUES(4,2);
INSERT INTO "master_services" VALUES(4,3);
INSERT INTO "master_services" VALUES(4,4);
INSERT INTO "master_services" VALUES(4,15);
INSERT INTO "master_services" VALUES(5,1);
INSERT INTO "master_services" VALUES(5,11);
INSERT INTO "master_services" VALUES(5,13);
INSERT INTO "master_services" VALUES(5,14);
INSERT INTO "master_services" VALUES(6,1);
INSERT INTO "master_services" VALUES(6,11);
INSERT INTO "master_services" VALUES(6,12);
INSERT INTO "master_services" VALUES(7,2);
INSERT INTO "master_services" VALUES(7,3);
INSERT INTO "master_services" VALUES(7,4);
INSERT INTO "master_services" VALUES(7,15);
INSERT INTO "master_services" VALUES(8,1);
INSERT INTO "master_services" VALUES(8,2);
INSERT INTO "master_services" VALUES(8,3);
INSERT INTO "master_services" VALUES(8,4);
INSERT INTO "master_services" VALUES(8,11);
INSERT INTO "master_services" VALUES(9,1);
INSERT INTO "master_services" VALUES(9,5);
INSERT INTO "master_services" VALUES(9,6);
INSERT INTO "master_services" VALUES(9,11);
INSERT INTO "master_services" VALUES(10,2);
INSERT INTO "master_services" VALUES(10,3);
INSERT INTO "master_services" VALUES(10,5);
INSERT INTO "master_services" VALUES(10,6);
INSERT INTO "master_services" VALUES(10,15);
CREATE TABLE masters (
  master_id        INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL UNIQUE,
  full_name        TEXT NOT NULL,
  specialization   TEXT NOT NULL,
  experience_years INTEGER NOT NULL CHECK (experience_years >= 0),
  is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);
INSERT INTO "masters" VALUES(1,2,'Dana Seitova','Colorist',8,1);
INSERT INTO "masters" VALUES(2,3,'Aliya Kenzhebekova','Women''s stylist',6,1);
INSERT INTO "masters" VALUES(3,4,'Madina Abenova','Colorist',4,1);
INSERT INTO "masters" VALUES(4,5,'Arman Zhumabekov','Barber',5,1);
INSERT INTO "masters" VALUES(5,6,'Zhanna Saparova','Hair care specialist',10,1);
INSERT INTO "masters" VALUES(6,7,'Saule Akhmetova','Wedding stylist',7,1);
INSERT INTO "masters" VALUES(7,8,'Timur Tulegenov','Barber',3,1);
INSERT INTO "masters" VALUES(8,9,'Kamila Bekova','Universal hairdresser',2,0);
INSERT INTO "masters" VALUES(9,10,'Aruzhan Omarova','Women''s stylist',3,1);
INSERT INTO "masters" VALUES(10,11,'Adilet Nurlanov','Barber',4,1);
CREATE TABLE reviews (
  review_id      INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL UNIQUE,
  rating         INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment        TEXT,
  FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE
);
INSERT INTO "reviews" VALUES(1,2,5,'Great result, very happy!');
INSERT INTO "reviews" VALUES(2,3,4,'Great result, very happy!');
INSERT INTO "reviews" VALUES(3,6,5,NULL);
INSERT INTO "reviews" VALUES(4,9,5,'Fast and neat work.');
INSERT INTO "reviews" VALUES(5,12,4,'Booking online was very convenient.');
INSERT INTO "reviews" VALUES(6,16,4,NULL);
INSERT INTO "reviews" VALUES(7,17,5,'Beautiful colour, thank you!');
INSERT INTO "reviews" VALUES(8,19,3,'The haircut is fine, a bit expensive.');
INSERT INTO "reviews" VALUES(9,21,4,'Will definitely come again.');
INSERT INTO "reviews" VALUES(10,25,4,'Great result, very happy!');
INSERT INTO "reviews" VALUES(11,28,5,'The master listened to all my wishes.');
INSERT INTO "reviews" VALUES(12,32,3,'Colour is slightly lighter than I wanted.');
INSERT INTO "reviews" VALUES(13,37,5,'The master listened to all my wishes.');
INSERT INTO "reviews" VALUES(14,40,5,'Will definitely come again.');
INSERT INTO "reviews" VALUES(15,42,4,'Friendly staff and cozy salon.');
INSERT INTO "reviews" VALUES(16,43,3,'The haircut is fine, a bit expensive.');
INSERT INTO "reviews" VALUES(17,46,2,'Not satisfied with the result.');
INSERT INTO "reviews" VALUES(18,51,4,'Fast and neat work.');
INSERT INTO "reviews" VALUES(19,52,3,'The haircut is fine, a bit expensive.');
INSERT INTO "reviews" VALUES(20,59,2,'Not satisfied with the result.');
INSERT INTO "reviews" VALUES(21,62,4,'Fast and neat work.');
INSERT INTO "reviews" VALUES(22,67,4,'Great result, very happy!');
INSERT INTO "reviews" VALUES(23,70,4,'The master listened to all my wishes.');
INSERT INTO "reviews" VALUES(24,76,5,NULL);
INSERT INTO "reviews" VALUES(25,78,5,NULL);
INSERT INTO "reviews" VALUES(26,82,5,'Fast and neat work.');
INSERT INTO "reviews" VALUES(27,83,4,'Will definitely come again.');
INSERT INTO "reviews" VALUES(28,85,4,'Booking online was very convenient.');
INSERT INTO "reviews" VALUES(29,86,2,'The appointment started 30 minutes late.');
INSERT INTO "reviews" VALUES(30,88,5,NULL);
INSERT INTO "reviews" VALUES(31,91,5,NULL);
INSERT INTO "reviews" VALUES(32,94,4,'Friendly staff and cozy salon.');
INSERT INTO "reviews" VALUES(33,99,5,'The master listened to all my wishes.');
INSERT INTO "reviews" VALUES(34,105,4,'Great result, very happy!');
CREATE TABLE services (
  service_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT NOT NULL UNIQUE,
  category     TEXT NOT NULL,
  duration_min INTEGER NOT NULL CHECK (duration_min > 0),
  price_kzt    INTEGER NOT NULL CHECK (price_kzt > 0)
);
INSERT INTO "services" VALUES(1,'Women''s haircut','Haircuts',60,7000);
INSERT INTO "services" VALUES(2,'Men''s haircut','Haircuts',40,4500);
INSERT INTO "services" VALUES(3,'Children''s haircut','Haircuts',30,3500);
INSERT INTO "services" VALUES(4,'Fringe trim','Haircuts',15,1500);
INSERT INTO "services" VALUES(5,'Bob cut','Haircuts',60,7000);
INSERT INTO "services" VALUES(6,'Wolf cut','Haircuts',60,8000);
INSERT INTO "services" VALUES(7,'Hair colouring (one tone)','Colouring',120,18000);
INSERT INTO "services" VALUES(8,'Root touch-up','Colouring',90,12000);
INSERT INTO "services" VALUES(9,'Highlights','Colouring',150,25000);
INSERT INTO "services" VALUES(10,'Balayage','Colouring',180,35000);
INSERT INTO "services" VALUES(11,'Blow-dry and styling','Styling',45,6000);
INSERT INTO "services" VALUES(12,'Evening hairstyle','Styling',90,15000);
INSERT INTO "services" VALUES(13,'Keratin treatment','Care',150,28000);
INSERT INTO "services" VALUES(14,'Hair botox','Care',120,22000);
INSERT INTO "services" VALUES(15,'Beard trim','Haircuts',30,3000);
CREATE TABLE users (
  user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE CHECK (email LIKE '%_@_%._%'),
  password_hash TEXT NOT NULL,                                   -- PBKDF2 hash, never plain text (R11)
  role          TEXT NOT NULL CHECK (role IN ('admin', 'master')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO "users" VALUES(1,'admin@salon.kz','pbkdf2:sha256:600000$dRH9vI6w7aP3sNRs$1de982586012a89f6aa167110fe98a8ed0e768191e99fd8703ea2cd0f6ae1574','admin','2026-08-25 09:00:00');
INSERT INTO "users" VALUES(2,'dana.seitova@salon.kz','pbkdf2:sha256:600000$l9rFOqGcZvYHffjL$a30f896f01992483af4fefa3fb6db19aff949155d80a8caf643c53f6d457a7cd','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(3,'aliya.kenzhebekova@salon.kz','pbkdf2:sha256:600000$OU9zhuOYLQWC1t1G$4a0fc77f28772dc8cca2eebab38a9f4d54b7b07dc776eadb89f341c952acd8f4','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(4,'madina.abenova@salon.kz','pbkdf2:sha256:600000$zvS07Xsvmdbmha5N$f08f58a4c65c4b0a20098c7a9b1e76f50a62b7c6fdbdfa229bd6721276eccab1','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(5,'arman.zhumabekov@salon.kz','pbkdf2:sha256:600000$3qSvZ4bHIlbreZhO$518135cac5ba7daa98197b4b5a038b2f010176035e0d344d1fafbaab3254aec5','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(6,'zhanna.saparova@salon.kz','pbkdf2:sha256:600000$TdwzfAUxDAWPw9JM$9c197c380b6ad38bb80243b33abe4dc262762312e4b9eb9937eab2671056e8b9','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(7,'saule.akhmetova@salon.kz','pbkdf2:sha256:600000$y2ptysqY4yts62nI$42a7d03a7b34ba70ee4d5bcd0d5059e06a0fb6f69b9a30b1f893f94b96c80e6e','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(8,'timur.tulegenov@salon.kz','pbkdf2:sha256:600000$vElarmEidiHCfbgC$5dd1a364b5f1f0701391671561910d7959f813924f2795ec383e3a49816a1274','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(9,'kamila.bekova@salon.kz','pbkdf2:sha256:600000$m1mAlkpwRGkRC6gY$8e77d6136cbd7fcba0f20c6a35bb36ff9919bdacf0bae8db99133c0f83dfeb6c','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(10,'aruzhan.omarova@salon.kz','pbkdf2:sha256:600000$WyQUNIBiXtIWCIGw$ef7ce958fd463ab4c77e94ba2b2f6d61f920bb3d20cc0717b853ba0cc4aca478','master','2026-08-26 10:00:00');
INSERT INTO "users" VALUES(11,'adilet.nurlanov@salon.kz','pbkdf2:sha256:600000$zBjtHUXWZhGq0UWU$484d182b1614828442cf0579d9b5fa5ea318a51d55345a9059f417ebeddf901c','master','2026-08-26 10:00:00');
CREATE UNIQUE INDEX ux_active_booking ON appointments (master_id, start_time) WHERE status <> 'cancelled';
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('users',11);
INSERT INTO "sqlite_sequence" VALUES('services',15);
INSERT INTO "sqlite_sequence" VALUES('masters',10);
INSERT INTO "sqlite_sequence" VALUES('clients',60);
INSERT INTO "sqlite_sequence" VALUES('appointments',150);
INSERT INTO "sqlite_sequence" VALUES('blocked_slots',12);
INSERT INTO "sqlite_sequence" VALUES('email_queue',150);
INSERT INTO "sqlite_sequence" VALUES('reviews',34);
COMMIT;
