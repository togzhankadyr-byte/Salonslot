-- SalonSlot – database schema (SQLite)
-- Requirement IDs (R1–R12) refer to Project Stage 1, Part B.
PRAGMA foreign_keys = ON;

-- Staff accounts only (R7). Clients book without an account (R3).
CREATE TABLE users (
  user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE CHECK (email LIKE '%_@_%._%'),
  password_hash TEXT NOT NULL,                                   -- PBKDF2 hash, never plain text (R11)
  role          TEXT NOT NULL CHECK (role IN ('admin', 'master')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Clients: contact details entered on step 4 of the booking (R3).
CREATE TABLE clients (
  client_id  INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name  TEXT NOT NULL,
  phone      TEXT NOT NULL UNIQUE CHECK (length(phone) >= 10),
  email      TEXT NOT NULL CHECK (email LIKE '%_@_%._%'),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Hairdressers (masters) shown on the salon page and in the booking (R2).
CREATE TABLE masters (
  master_id        INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL UNIQUE,
  full_name        TEXT NOT NULL,
  specialization   TEXT NOT NULL,
  experience_years INTEGER NOT NULL CHECK (experience_years >= 0),
  is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Price list (R1).
CREATE TABLE services (
  service_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT NOT NULL UNIQUE,
  category     TEXT NOT NULL,
  duration_min INTEGER NOT NULL CHECK (duration_min > 0),
  price_kzt    INTEGER NOT NULL CHECK (price_kzt > 0)
);

-- Which master provides which service (resolves the many-to-many relationship).
CREATE TABLE master_services (
  master_id  INTEGER NOT NULL,
  service_id INTEGER NOT NULL,
  PRIMARY KEY (master_id, service_id),
  FOREIGN KEY (master_id)  REFERENCES masters(master_id)   ON DELETE CASCADE,
  FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE
);

-- Bookings – the main table (R3, R4, R6).
CREATE TABLE appointments (
  appointment_id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id      INTEGER NOT NULL,
  master_id      INTEGER NOT NULL,
  service_id     INTEGER NOT NULL,
  start_time     TEXT NOT NULL,                                   -- 'YYYY-MM-DD HH:MM'
  status         TEXT NOT NULL DEFAULT 'booked'
                 CHECK (status IN ('booked', 'completed', 'cancelled')),
  cancel_code    TEXT NOT NULL UNIQUE,                            -- reference code for the cancel link (R6)
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (client_id)  REFERENCES clients(client_id)   ON DELETE CASCADE,
  FOREIGN KEY (master_id)  REFERENCES masters(master_id)   ON DELETE RESTRICT,
  FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE RESTRICT
);

-- No double booking (R4): one active booking per master and start time.
-- Cancelled bookings are not counted, so a cancelled time can be booked again (R6).
CREATE UNIQUE INDEX ux_active_booking ON appointments (master_id, start_time) WHERE status <> 'cancelled';

-- Times blocked by the administrator for a break or a day off (R8).
CREATE TABLE blocked_slots (
  block_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  master_id  INTEGER NOT NULL,
  start_time TEXT NOT NULL,
  end_time   TEXT NOT NULL,
  reason     TEXT NOT NULL DEFAULT 'Break',
  created_by INTEGER NOT NULL,
  CHECK (end_time > start_time),
  FOREIGN KEY (master_id)  REFERENCES masters(master_id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- Confirmation e-mails waiting to be sent by the mail service (R5).
CREATE TABLE email_queue (
  email_id       INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL,
  to_email       TEXT NOT NULL,
  subject        TEXT NOT NULL,
  body           TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed')),
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE
);

-- Ratings for completed visits, shown in the "Reviews" tab of the salon page.
CREATE TABLE reviews (
  review_id      INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL UNIQUE,
  rating         INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment        TEXT,
  FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE CASCADE
);
