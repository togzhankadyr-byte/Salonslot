@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo SalonSlot - starting...

if not exist "app.py" (
  echo [ERROR] app.py not found. Extract the ZIP first: right click - Extract All, then run start.bat from the app folder.
  pause & exit /b
)

set PY=
python --version >/dev/null 2>&1 && set PY=python
if not defined PY py --version >/dev/null 2>&1 && set PY=py
if not defined PY (
  echo [ERROR] Python is not installed. Install it from python.org and tick "Add python.exe to PATH".
  start https://www.python.org/downloads/
  pause & exit /b
)

%PY% -c "import flask" >/dev/null 2>&1
if errorlevel 1 (
  echo Installing Flask - needs internet, only the first time...
  %PY% -m pip install flask
)

start "" /min cmd /c "timeout /t 3 >nul & start http://127.0.0.1:5000"
%PY% app.py
echo.
echo The server stopped. If you see an error above, send a photo of this window.
pause
