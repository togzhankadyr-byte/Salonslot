"""Daily backup of salon_booking.db (Part B3).
Writes a full SQL dump (same result as `sqlite3 salon_booking.db .dump`) and checks it by
restoring into a temporary database and comparing the row count of every table.
Usage:  python backup.py            -> backups/backup_YYYY-MM-DD.sql
"""
import datetime
import sqlite3
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DB = HERE / "salon_booking.db"


def backup(out_dir: Path) -> Path:
    out_dir.mkdir(exist_ok=True)
    path = out_dir / f"backup_{datetime.date.today():%Y-%m-%d}.sql"
    with sqlite3.connect(DB) as con, open(path, "w", encoding="utf-8") as f:
        for line in con.iterdump():
            f.write(line + "\n")
    return path


def restore_test(path: Path) -> bool:
    src = sqlite3.connect(DB)
    tmp = sqlite3.connect(":memory:")
    tmp.executescript(path.read_text(encoding="utf-8"))
    ok = True
    for (t,) in src.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
        a = src.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        b = tmp.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        print(f"{t:<16} {a:>4} -> {b:>4}  {'OK' if a == b else 'DIFF'}")
        ok &= a == b
    print("integrity_check:", tmp.execute("PRAGMA integrity_check").fetchone()[0])
    return ok


if __name__ == "__main__":
    p = backup(HERE / "backups")
    print("saved", p.name)
    sys.exit(0 if restore_test(p) else 1)
