@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo SalonSlot - phone mode (the phone must be on the same Wi-Fi)
set SALON_HOST=0.0.0.0
python app.py
pause
