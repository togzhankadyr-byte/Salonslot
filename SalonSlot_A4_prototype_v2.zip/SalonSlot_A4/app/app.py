"""
SalonSlot – online booking for a hair salon (ICT Assignment 3, Part D1)

Run:  python app.py   then open http://127.0.0.1:5000
Database: salon_booking.db (SQLite) in the same folder.

Requirement IDs (R1–R12) refer to Project Stage 1, Part B:
  R1 price list · R2 only free times · R3 booking with name, phone, e-mail · R4 no double booking
  R5 confirmation e-mail · R6 cancel with a reference code · R7 staff login · R8 schedule and block out slot
  R11 hashed passwords; HTTPS in production (Firebase Hosting)
"""
import json
import logging
import os
import secrets
import sqlite3
import time
from datetime import date, datetime, timedelta
from functools import wraps

from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "salon_booking.db")

# bookings are in salon time (UTC+5); cloud servers run in UTC, so the app sets the time zone itself
os.environ["TZ"] = os.environ.get("SALON_TZ", "Etc/GMT-5")
if hasattr(time, "tzset"):
    time.tzset()
app = Flask(__name__)
app.secret_key = os.environ.get("SALON_SECRET_KEY", os.urandom(24))
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

# ---------------------------------------------------------------- media (Assignment 4)
# MEDIA_MODE=original shows the camera photos as they are (used once, to measure "before");
# the default "optimised" shows resized WebP copies made by tools/optimise_images.py.
MEDIA_MODE = os.environ.get("MEDIA_MODE", "optimised")
PHOTOS_FILE = os.path.join(BASE_DIR, "static", "img", "photos.json")
PHOTOS = json.load(open(PHOTOS_FILE, encoding="utf-8")) if os.path.exists(PHOTOS_FILE) else {}


@app.context_processor
def media_context():
    return {"photos": PHOTOS, "media_mode": MEDIA_MODE}


# security log: staff logins, denied access, bookings, cancellations, blocked slots
log = logging.getLogger("salonslot.security")
log.setLevel(logging.INFO)
log.propagate = False
_handler = logging.FileHandler(os.path.join(BASE_DIR, "security.log"), encoding="utf-8")
_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
log.addHandler(_handler)

OPEN_HOUR, CLOSE_HOUR = 9, 19          # 09:00–19:00, closed on Sunday (Stage 1 wireframe)
SLOT_MIN = 30                          # free times are offered every 30 minutes
DAYS_AHEAD = 7                         # the client chooses one of the next 7 working days
MAX_FAILED_LOGINS, LOCK_SECONDS = 5, 300
failed_logins = {}


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def fmt_price(v):
    return "{:,}".format(v).replace(",", " ") + " ₸"


app.jinja_env.filters["price"] = fmt_price


# ---------------------------------------------------------------- free slots (R2, R4, R8)
def busy_intervals(db, master_id, day):
    """Booked appointments and blocked slots of one master on one day."""
    rows = db.execute(
        """SELECT a.start_time AS s, datetime(a.start_time, '+' || sv.duration_min || ' minutes') AS e
           FROM appointments a JOIN services sv ON sv.service_id = a.service_id
           WHERE a.master_id = ? AND a.status = 'booked' AND date(a.start_time) = ?
           UNION ALL
           SELECT start_time, end_time FROM blocked_slots
           WHERE master_id = ? AND date(start_time) <= ? AND date(end_time) >= ?""",
        (master_id, day, master_id, day, day),
    ).fetchall()
    out = []
    for r in rows:
        out.append((datetime.fromisoformat(r["s"][:16]), datetime.fromisoformat(r["e"][:16])))
    return out


def free_times(db, master_id, service_id, day):
    """Only free start times are returned, so a client cannot pick a busy slot (R2)."""
    duration = db.execute("SELECT duration_min FROM services WHERE service_id = ?", (service_id,)).fetchone()
    if not duration or day.weekday() == 6:
        return []
    length = timedelta(minutes=duration["duration_min"])
    busy = busy_intervals(db, master_id, day.isoformat())
    close = datetime.combine(day, datetime.min.time()).replace(hour=CLOSE_HOUR)
    t = datetime.combine(day, datetime.min.time()).replace(hour=OPEN_HOUR)
    now = datetime.now()
    result = []
    while t + length <= close:
        if t > now and not any(t < e and t + length > s for s, e in busy):
            result.append(t.strftime("%H:%M"))
        t += timedelta(minutes=SLOT_MIN)
    return result


def masters_for(db, service_id):
    return db.execute(
        """SELECT m.master_id, m.full_name, m.specialization FROM masters m
           JOIN master_services ms ON ms.master_id = m.master_id
           WHERE ms.service_id = ? AND m.is_active = 1 ORDER BY m.full_name""",
        (service_id,),
    ).fetchall()


def next_days():
    days, d = [], date.today()
    while len(days) < DAYS_AHEAD:
        if d.weekday() != 6:
            days.append(d)
        d += timedelta(days=1)
    return days


# ---------------------------------------------------------------- public pages (no account needed)
@app.route("/")
def salon():
    """Salon page: services with prices (R1), masters and reviews."""
    db = get_db()
    services = db.execute(
        "SELECT service_id, name, category, duration_min, price_kzt FROM services ORDER BY category, price_kzt"
    ).fetchall()
    masters = db.execute(
        """SELECT m.master_id, m.full_name, m.specialization, m.experience_years,
                  ROUND(AVG(r.rating), 1) AS rating, COUNT(r.review_id) AS reviews
           FROM masters m
           LEFT JOIN appointments a ON a.master_id = m.master_id
           LEFT JOIN reviews r ON r.appointment_id = a.appointment_id
           WHERE m.is_active = 1 GROUP BY m.master_id ORDER BY m.full_name"""
    ).fetchall()
    summary = db.execute("SELECT ROUND(AVG(rating), 1) AS avg, COUNT(*) AS n FROM reviews").fetchone()
    latest = db.execute(
        """SELECT r.rating, r.comment, c.full_name, s.name AS service FROM reviews r
           JOIN appointments a ON a.appointment_id = r.appointment_id
           JOIN clients c ON c.client_id = a.client_id
           JOIN services s ON s.service_id = a.service_id
           WHERE r.comment IS NOT NULL ORDER BY a.start_time DESC LIMIT 4"""
    ).fetchall()
    categories = sorted({s["category"] for s in services})
    return render_template("salon.html", services=services, masters=masters, summary=summary,
                           latest=latest, categories=categories, open_h=OPEN_HOUR, close_h=CLOSE_HOUR)


@app.route("/book", methods=["GET", "POST"])
def book():
    """Four-step booking: 1 service · 2 master · 3 day and time · 4 contact details (R2, R3)."""
    db = get_db()
    args = request.values
    service = master = None
    if args.get("service", "").isdigit():
        service = db.execute("SELECT * FROM services WHERE service_id = ?", (int(args["service"]),)).fetchone()
    if service and args.get("master"):
        if args["master"] == "any":
            master = "any"
        elif args["master"].isdigit():
            master = db.execute("SELECT * FROM masters WHERE master_id = ? AND is_active = 1",
                                (int(args["master"]),)).fetchone()
    days = next_days()
    day = None
    try:
        day = date.fromisoformat(args.get("day", ""))
    except ValueError:
        day = days[0]
    if day not in days:
        day = days[0]
    time_ = args.get("time")

    if not service:
        services = db.execute("SELECT * FROM services ORDER BY category, price_kzt").fetchall()
        return render_template("book.html", step=1, services=services)
    if not master:
        return render_template("book.html", step=2, service=service, masters=masters_for(db, service["service_id"]))

    # step 3: free times – for one master, or the earliest free master per time ("any available master")
    if master == "any":
        options = {}
        for m in masters_for(db, service["service_id"]):
            for t in free_times(db, m["master_id"], service["service_id"], day):
                options.setdefault(t, m)
        times = sorted(options)
    else:
        options = None
        times = free_times(db, master["master_id"], service["service_id"], day)

    if not time_ or time_ not in times:
        if time_:
            flash("This time has just been taken. Please choose another one.", "error")
        return render_template("book.html", step=3, service=service, master=master, days=days, day=day, times=times)

    chosen = options[time_] if options else master
    if request.method == "POST":
        error, code = create_booking(db, service, chosen, day, time_, request.form)
        if error:
            flash(error, "error")
        else:
            return redirect(url_for("confirmed", code=code))
    return render_template("book.html", step=4, service=service, master=master, chosen=chosen,
                           day=day, time=time_, form=request.form)


def create_booking(db, service, master, day, time_, form):
    """Server-side validation, then parameterised INSERTs (R3, R4, R5, R6)."""
    name = form.get("full_name", "").strip()
    phone = "".join(ch for ch in form.get("phone", "") if ch.isdigit() or ch == "+")
    email = form.get("email", "").strip().lower()
    if len(name) < 2 or len(name) > 80:
        return "Please enter your name.", None
    if len(phone) < 11 or len(phone) > 13:
        return "Please enter a phone number such as +7 701 123 45 67.", None
    if "@" not in email or "." not in email.split("@")[-1] or len(email) > 120:
        return "Please enter a valid e-mail address.", None
    if not form.get("consent"):
        return "Please agree to the processing of your personal data.", None

    # the time is checked again on the server, because another client may have booked it a second ago (R4)
    if time_ not in free_times(db, master["master_id"], service["service_id"], day):
        return "This time has just been taken. Please choose another one.", None

    start = f"{day.isoformat()} {time_}"
    code = secrets.token_urlsafe(6).upper().replace("-", "X").replace("_", "Y")[:8]
    try:
        row = db.execute("SELECT client_id FROM clients WHERE phone = ?", (phone,)).fetchone()
        if row:
            client_id = row["client_id"]
            db.execute("UPDATE clients SET full_name = ?, email = ? WHERE client_id = ?", (name, email, client_id))
        else:
            client_id = db.execute("INSERT INTO clients (full_name, phone, email) VALUES (?, ?, ?)",
                                   (name, phone, email)).lastrowid
        appointment_id = db.execute(
            "INSERT INTO appointments (client_id, master_id, service_id, start_time, status, cancel_code) "
            "VALUES (?, ?, ?, ?, 'booked', ?)",
            (client_id, master["master_id"], service["service_id"], start, code),
        ).lastrowid
        cancel_link = url_for("cancel", code=code, _external=True)
        db.execute(
            "INSERT INTO email_queue (appointment_id, to_email, subject, body) VALUES (?, ?, ?, ?)",
            (appointment_id, email, "SalonSlot: your booking is confirmed",
             f"Hello, {name.split()[0]}! Your booking: {service['name']} with {master['full_name']} "
             f"on {day.strftime('%d.%m.%Y')} at {time_}. To cancel, open {cancel_link}"),
        )
        db.commit()
    except sqlite3.IntegrityError:          # unique index ux_active_booking – the last line of defence (R4)
        db.rollback()
        return "This time has just been taken. Please choose another one.", None
    log.info("Booking created: appointment %s, master %s, %s", appointment_id, master["master_id"], start)
    return None, code


@app.route("/confirmed/<code>")
def confirmed(code):
    a = booking_by_code(code)
    return render_template("confirmed.html", a=a)


def booking_by_code(code):
    a = get_db().execute(
        """SELECT a.appointment_id, a.start_time, a.status, a.cancel_code, s.name AS service, s.price_kzt,
                  m.full_name AS master, c.full_name AS client, c.email
           FROM appointments a JOIN services s ON s.service_id = a.service_id
           JOIN masters m ON m.master_id = a.master_id JOIN clients c ON c.client_id = a.client_id
           WHERE a.cancel_code = ?""",
        (code.upper(),),
    ).fetchone()
    if not a:
        abort(404)
    return a


@app.route("/cancel/<code>", methods=["GET", "POST"])
def cancel(code):
    """The client cancels with the reference code from the e-mail; the time becomes free again (R6)."""
    a = booking_by_code(code)
    if request.method == "POST" and a["status"] == "booked":
        db = get_db()
        db.execute("UPDATE appointments SET status = 'cancelled' WHERE cancel_code = ? AND status = 'booked'",
                   (a["cancel_code"],))
        db.commit()
        log.info("Booking cancelled by client: appointment %s", a["appointment_id"])
        flash("Your booking is cancelled. The time is free again.", "success")
        return redirect(url_for("cancel", code=code))
    return render_template("cancel.html", a=a)


@app.route("/find", methods=["GET", "POST"])
def find():
    """A client who lost the e-mail can type the reference code (R6)."""
    if request.method == "POST":
        code = "".join(ch for ch in request.form.get("code", "") if ch.isalnum()).upper()
        if get_db().execute("SELECT 1 FROM appointments WHERE cancel_code = ?", (code,)).fetchone():
            return redirect(url_for("cancel", code=code))
        flash("No booking with this code.", "error")
    return render_template("find.html")


# ---------------------------------------------------------------- staff login (R7, R11)
def staff_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if roles and session.get("role") not in roles:
                log.warning("Access denied: user %s (%s) -> %s", session["user_id"], session.get("role"), request.path)
                return render_template("error.html", message="You do not have access to this page."), 403
            return view(*args, **kwargs)
        return wrapped
    return decorator


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        count, since = failed_logins.get(email, [0, 0])
        if count >= MAX_FAILED_LOGINS and time.time() - since < LOCK_SECONDS:
            log.warning("Login blocked (too many attempts): %s", email)
            flash("Too many failed attempts. Try again in 5 minutes.", "error")
            return render_template("login.html")
        user = get_db().execute(
            "SELECT user_id, email, password_hash, role FROM users WHERE email = ?", (email,)
        ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            failed_logins.pop(email, None)
            session.clear()
            session["user_id"], session["role"] = user["user_id"], user["role"]
            m = get_db().execute("SELECT master_id, full_name FROM masters WHERE user_id = ?",
                                 (user["user_id"],)).fetchone()
            session["master_id"] = m["master_id"] if m else None
            session["name"] = m["full_name"] if m else "Administrator"
            log.info("Login OK: %s (%s)", email, user["role"])
            return redirect(url_for("schedule"))
        failed_logins[email] = [count + 1, since if count else time.time()]
        log.warning("Login failed: %s", email)
        flash("Wrong email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("salon"))


# ---------------------------------------------------------------- admin schedule (R8)
@app.route("/admin")
@staff_required("admin", "master")
def schedule():
    db = get_db()
    try:
        day = date.fromisoformat(request.args.get("day", ""))
    except ValueError:
        day = date.today()
    masters = db.execute("SELECT master_id, full_name FROM masters WHERE is_active = 1 ORDER BY full_name").fetchall()
    if session["role"] == "master":                 # a master sees only his or her own schedule
        master_filter = session["master_id"]
    else:
        f = request.args.get("master", "")
        master_filter = int(f) if f.isdigit() else None
    where, params = "date(a.start_time) = ?", [day.isoformat()]
    bwhere, bparams = "date(b.start_time) <= ? AND date(b.end_time) >= ?", [day.isoformat(), day.isoformat()]
    if master_filter:
        where += " AND a.master_id = ?"; params.append(master_filter)
        bwhere += " AND b.master_id = ?"; bparams.append(master_filter)
    rows = db.execute(
        f"""SELECT a.appointment_id, substr(a.start_time, 12, 5) AS time, a.status, s.name AS service,
                   s.duration_min, m.full_name AS master, c.full_name AS client, c.phone
            FROM appointments a JOIN services s ON s.service_id = a.service_id
            JOIN masters m ON m.master_id = a.master_id JOIN clients c ON c.client_id = a.client_id
            WHERE {where} ORDER BY a.start_time""", params).fetchall()
    blocks = db.execute(
        f"""SELECT b.block_id, substr(b.start_time, 12, 5) AS start, substr(b.end_time, 12, 5) AS end,
                   b.reason, m.full_name AS master
            FROM blocked_slots b JOIN masters m ON m.master_id = b.master_id
            WHERE {bwhere} ORDER BY b.start_time""", bparams).fetchall()
    booked = sum(1 for r in rows if r["status"] == "booked")
    times = [f"{h:02d}:{mm:02d}" for h in range(OPEN_HOUR, CLOSE_HOUR) for mm in (0, 30)]
    return render_template("admin.html", day=day, rows=rows, blocks=blocks, masters=masters,
                           master_filter=master_filter, booked=booked, times=times,
                           prev_day=day - timedelta(days=1), next_day=day + timedelta(days=1))


@app.route("/admin/latest")
@staff_required("admin", "master")
def latest_booking():
    """Newest active booking – the schedule page asks every 10 s and shows a banner (+ optional sound)."""
    sql = """SELECT a.appointment_id, a.start_time, m.full_name AS master, s.name AS service
             FROM appointments a JOIN masters m ON m.master_id = a.master_id
             JOIN services s ON s.service_id = a.service_id WHERE a.status = 'booked'"""
    params = []
    if session["role"] == "master":
        sql += " AND a.master_id = ?"; params.append(session["master_id"])
    row = get_db().execute(sql + " ORDER BY a.appointment_id DESC LIMIT 1", params).fetchone()
    return jsonify(dict(row) if row else {})


@app.route("/admin/cancel/<int:appointment_id>", methods=["POST"])
@staff_required("admin")
def admin_cancel(appointment_id):
    db = get_db()
    db.execute("UPDATE appointments SET status = 'cancelled' WHERE appointment_id = ? AND status = 'booked'",
               (appointment_id,))
    db.commit()
    log.info("Booking cancelled by admin %s: appointment %s", session["user_id"], appointment_id)
    return redirect(request.referrer or url_for("schedule"))


@app.route("/admin/block", methods=["POST"])
@staff_required("admin")
def block_slot():
    """Block out a time for a break or a day off – clients will not see it (R8)."""
    db = get_db()
    f = request.form
    try:
        master_id = int(f.get("master_id", ""))
        start = datetime.strptime(f"{f.get('day')} {f.get('start')}", "%Y-%m-%d %H:%M")
        end = start + timedelta(minutes=int(f.get("minutes", "60")))
    except ValueError:
        flash("Please choose a master, a day and a time.", "error")
        return redirect(url_for("schedule"))
    clash = [s for s, e in busy_intervals(db, master_id, start.date().isoformat()) if start < e and end > s]
    if clash:
        flash("This master already has a booking or a block at this time.", "error")
    else:
        db.execute("INSERT INTO blocked_slots (master_id, start_time, end_time, reason, created_by) "
                   "VALUES (?, ?, ?, ?, ?)",
                   (master_id, start.strftime("%Y-%m-%d %H:%M"), end.strftime("%Y-%m-%d %H:%M"),
                    f.get("reason", "Break")[:40] or "Break", session["user_id"]))
        db.commit()
        log.info("Slot blocked by admin %s: master %s, %s", session["user_id"], master_id, start)
        flash("The time is blocked. Clients will not see it.", "success")
    return redirect(url_for("schedule", day=start.date().isoformat(), master=f.get("filter", "")))


@app.route("/admin/unblock/<int:block_id>", methods=["POST"])
@staff_required("admin")
def unblock(block_id):
    db = get_db()
    db.execute("DELETE FROM blocked_slots WHERE block_id = ?", (block_id,))
    db.commit()
    log.info("Slot unblocked by admin %s: block %s", session["user_id"], block_id)
    return redirect(request.referrer or url_for("schedule"))


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        # rebuild the database from the two SQL files (same result as the delivered salon_booking.db)
        with sqlite3.connect(DB_PATH) as con:
            for name in ("schema.sql", "seed_data.sql"):
                with open(os.path.join(BASE_DIR, name), encoding="utf-8") as f:
                    con.executescript(f.read())
        print("salon_booking.db created from schema.sql + seed_data.sql")
    # Default: only this computer can open the site. start_phone.bat sets SALON_HOST=0.0.0.0 so a phone
    # on the same Wi-Fi can open it too (used to record the demo video); close it after recording.
    host = os.environ.get("SALON_HOST", "127.0.0.1")
    if host == "0.0.0.0":
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("192.168.0.1", 80))          # no data is sent – only finds the Wi-Fi address
            ip = s.getsockname()[0]; s.close()
        except OSError:
            ip = socket.gethostbyname(socket.gethostname())
        print("\n" + "=" * 54)
        print("  Open this address on your phone (same Wi-Fi):")
        print(f"      http://{ip}:5000")
        print("=" * 54 + "\n")
    app.run(host=host, port=5000, debug=False)
