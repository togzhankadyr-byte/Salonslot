# PythonAnywhere: Web tab -> "WSGI configuration file" -> replace everything with these lines,
# change USERNAME to your PythonAnywhere user name.
import os
import sys

APP_DIR = "/home/USERNAME/SalonSlot_A4/app"
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)
os.chdir(APP_DIR)

from app import app as application  # noqa: E402
